;<?php/*

[general]
name="LibCkEditor"
version="2.07"
addon_type="LIBRARY"
encoding="UTF-8"
mysql_character_set_database="latin1,utf8"
description="CkEditor, an open source WYSIWYG text editor"
description.fr="CkEditor, un éditeur de texte WYSIWYG open-source"
delete=1
ov_version="7.0.0"
php_version="5.1.0"
author="Antoine Gallet ( antoine.gallet@cantico.fr )"
icon="icon.png"
addon_access_control="0"
configuration_page="configuration"
db_prefix="lcke_"

[addons]
widgets="0.2.12"

[functionalities]
jquery="Available"
;*/?>
