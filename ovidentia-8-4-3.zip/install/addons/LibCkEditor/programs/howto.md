GO on http://ckeditor.com/builder
In 1. choose preset : full
In 2. Add SyntaxHilighter Interface
In 3. Finalize and download : Add French language

Check the optimized radio is selected and download.
After that remove the sample folder in the downloaded zip.