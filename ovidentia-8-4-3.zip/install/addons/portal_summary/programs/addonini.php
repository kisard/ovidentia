;<?php/*

[general]
name                          ="portal_summary"
version                       ="0.1.3"
addon_type			          ="EXTENSION"
encoding                      ="UTF-8"
mysql_character_set_database  ="utf8,latin1"
description                   ="Portal summary, new items from articles, comments, forum posts, files, calendar events"
description.fr                ="Nouveautés du portail, nouveaux éléments parmi les articles, commentaires, contributions de forum, fichiers, événements d'agenda"
delete                        ="1"
addon_access_control          ="0"
author                        ="Cantico"
ov_version                    ="7.1.0"
php_version                   ="5.1.0"
mysql_version                 ="4.1.0"

icon                          ="summary.png"

;*/?>