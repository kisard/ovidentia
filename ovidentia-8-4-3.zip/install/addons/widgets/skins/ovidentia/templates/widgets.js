/*
 * widgets.js
 * add some default optional js actions associated to css classes
 * depend only from ovidentia.js
 */



window.bab = {
    initFunctions: [],

    addInitFunction: function (f) {
        this.initFunctions.push(f);
    },

    init: function (domNode) {
        for (var i = 0; i < this.initFunctions.length; i++) {
            var initFunction = this.initFunctions[i];
            initFunction(domNode);
        }
    }
};




window.babAddonWidgets = {

    neededJavascripts: {},

    /**
     * @param	domNode	Objects
     */
    reload: function(/* domNodes */) {

        var nbArgs = arguments.length;
        var reloadNode = [];
        for (var i = 0; i < nbArgs; i++) {

            domNode = arguments[i];

            do {
                if (domNode.id) {
                    var meta = window.babAddonWidgets.getMetadata(domNode.id);
                    if (meta.delayedAction) {
                        reloadNode.push(domNode);
                        break;
                    }
                }
                if (domNode.widgetParentNode) {
                    domNode = domNode.widgetParentNode;
                } else {
                    domNode = domNode.parentNode;
                }
            } while (domNode);

            if (!domNode) {
                window.location.reload();
                return;
            }
        }

        var focusedId = document.activeElement.id;
        var promises = [];
        var initList = [];

        for (index = 0; index < reloadNode.length; ++index) {
            var currentNode = reloadNode[index];
            var meta = window.babAddonWidgets.getMetadata(currentNode.id);
            var parent = jQuery(currentNode).parent().get(0);
            if(parent) {
                jQuery(parent).addClass('widget-delayed-action-loading');
                jQuery(parent).find('input').attr("disabled", "disabled");

                promises.push(
                    jQuery.ajax({
                        url: meta.delayedAction,
                        cache: false,
                        success: function(response, textStatus) {
                            jQuery(parent).removeClass('widget-delayed-action-loading');
                            jQuery(parent).removeProp('disabled');
                            jQuery(parent).css('visibility', 'hidden');
                            if (textStatus != 'notmodified') {
                            	jQuery(parent).html(response);
                            }
                            var newmeta = window.babAddonWidgets.getMetadata(parent.firstChild.id);
                            newmeta.delayedAction = meta.delayedAction;
                            window.babAddonWidgets.addMetadata(parent.firstChild.id, newmeta);
                            jQuery(parent).css('visibility', 'visible');

                            window.bab.init(parent);
                            window.bab.init(jQuery('body > .ui-dialog').get(0));
                            
                            initList.push(parent);
                        }
                    })
                );
            }
        }

        var when = jQuery.when.apply(jQuery, promises).then(function(){
            jQuery('.widget-form.widget-persistent').each(function() {
                widgets_initFormData(this);
                /*
                for (var i=0; i<initList.length; i++) {
                	window.bab.init(initList[i]);
                }
                */
            });
            if(focusedId) {
                var focusedElement = document.getElementById(focusedId);
                if (focusedElement)  {
                    focusedElement.focus();
                }
            }
        });;
    },


    /**
     * @param	string	metaname
     * @param	arr		Object
     * @return Object
     */
    addMetadata: function(metaname, arr) {

        if (typeof window.babAddonWidgets.metadata == 'undefined') {
            window.babAddonWidgets.metadata = {};
        }

        window.babAddonWidgets.metadata[metaname] = arr;
    },


    /**
     * @param	string	metaname
     * @return Object
     */
    getMetadata: function(metaname) {

        if (typeof window.babAddonWidgets.metadata == 'undefined' || typeof window.babAddonWidgets.metadata[metaname] == 'undefined') {
            return {};
        }

        return window.babAddonWidgets.metadata[metaname];
    },




    /**
     * @param string	url		The url of the
     */
    _loadScript: function(url) {
        var scripts = document.scripts;
        var nbScripts = scripts.length;
        var i = 0;
        for (i = 0; i < nbScripts; i++) {
            if (url == scripts[i].getAttribute('src')) {
                return true;
            }
        }

        var script = document.createElement('script');
        script.setAttribute('type', 'text/javascript');
        script.setAttribute('src', url);
        script.setAttribute('defer', 'defer');
        document.body.appendChild(script);

//		console.debug("Append script (" + url + ")");

        script.onreadystatechange = function () {
            if (this.readyState == 'complete' || this.readyState == 'loaded') {
                for (var i = 0; i < window.babAddonWidgets.neededJavascripts[url].length; i++) {
                    var node = document.getElementById(window.babAddonWidgets.neededJavascripts[url][i]);
                    if (node) {
                        window.bab.init(node.parentNode);
                    }
                }
            }
        };

        script.onload = function() {
            for (var i = 0; i < window.babAddonWidgets.neededJavascripts[url].length; i++) {
                if (window.babAddonWidgets.neededJavascripts[url][i]) {
                    var node = document.getElementById(window.babAddonWidgets.neededJavascripts[url][i]);
                    if (node) {
                        window.bab.init(node.parentNode);
                    }
                }
            }
        };

    },




    /**
     * Include a javascript file from the widget addon.
     * @param string	widget_id	The dom element id requiring the javascript for initialization.
     * @param string	url
     */
    needScript: function(widget_id, url) {
        // console.debug('babAddonWidgets.needScript(' + widget_id + ', ' + url + ')');

        if (typeof window.babAddonWidgets.neededJavascripts[url] == 'undefined') {
            window.babAddonWidgets.neededJavascripts[url] = [];
        }
        window.babAddonWidgets.neededJavascripts[url].push(widget_id);

        // IE8 : document.readyState is "interactive" while the DOM is not fully loaded
        if ( document.readyState === "complete" || ( document.readyState !== "loading" && document.addEventListener )) {
            for (var url in window.babAddonWidgets.neededJavascripts) {
                window.babAddonWidgets._loadScript(url);
            }
        }

    },




    /**
     * Add a link to the specified css stylesheet file in the page head.
     * @param string	file
     */
    stylesheet: function(url) {
        if (!document.createElement || !document.getElementsByTagName) {
            alert('Your browser can\'t deal with the DOM standard. That means it\'s old.');
            return false;
        }

        var head = document.getElementsByTagName('head')[0];

        var links = head.getElementsByTagName('link');
        var nbLinks = links.length;
        var i = 0;
        for (i = 0; i < nbLinks; i++) {
            if (url == links[i].getAttribute('href')) {
                return true;
            }
        }

        var link = document.createElement('link');
        link.setAttribute('type', 'text/css');
        link.setAttribute('rel', 'stylesheet');
        link.setAttribute('href', url);

        head.appendChild(link);
        return true;
    }

};












document.onreadystatechange = function () {
    // IE8 : document.readyState is "interactive" while the DOM is not fully loaded
    if ( document.readyState === "complete" || ( document.readyState !== "loading" && document.addEventListener )) {
        for (var url in window.babAddonWidgets.neededJavascripts) {
            window.babAddonWidgets._loadScript(url);
        }
    }
};

