/*
function widget_groupPickerInit(domNode)
{
	jQuery(domNode).find('.widget-grouppicker')
	.each(function() {
		var groupPicker = jQuery(this);
		var groupPickerLineEdit = jQuery(this).children().get(0);
		jQuery(this).append('<input type="hidden" name="' + groupPickerLineEdit.name + '" value="' + groupPickerLineEdit.value + '" />');
		
		jQuery(groupPickerLineEdit).hide();

		var text = window.babAddonWidgets.getMetadata(groupPickerLineEdit.id).groupName;
		jQuery(this).append('<div>' + text + '</div>');
		groupPickerLineEdit.name = '';
	}
	)
	.click(function() {
		var groupPicker = jQuery(this);
		var groupPickerLineEdit = jQuery(jQuery(this).children().get(0));
		var groupPickerHidden = jQuery(jQuery(this).children().get(1));
		var groupPickerLabel = jQuery(jQuery(this).children().get(2));
		bab_dialog.selectgroups(function(param) {
			groupPickerLabel.text(param['content']);
			groupPickerHidden.val(param['id']);
		}, 'selectable_groups&memorize'
		);
	}
	);

}


window.bab.addInitFunction(widget_groupPickerInit);
*/