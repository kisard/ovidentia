
jQuery(document).ready(function() {

	jQuery('.widget-uploader').change(function() {
//		alert('changed');
	});
	
});