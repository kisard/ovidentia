
function widget_datePickerInit(domNode)
{
    highlightDateMax = new Date();
    highlightDateMin = new Date(highlightDateMax);
    highlightDateMin.setDate(highlightDateMin.getDate() - 1);
    if (jQuery.datepicker) {
        // Prepare datepicker widgets
        jQuery(domNode).find(".widget-datepicker").not('.widget-init-done').each(function() {
            var meta = window.babAddonWidgets.getMetadata(this.id);

            var highlightedDateMin = highlightDateMin;
            var highlightedDateMax = highlightDateMax;
            
            if (meta.highlightedDateMin) {
                highlightedDateMin = new Date(meta.highlightedDateMin + 'T00:00:00');
                highlightedDateMax = new Date(highlightedDateMin);
                highlightedDateMax.setDate(highlightedDateMax.getDate() + 1);
            }
            if (meta.highlightedDateMax) {
                highlightedDateMax = new Date(meta.highlightedDateMax + 'T00:00:00');
            }
            
            if (typeof meta.format == 'undefined') {
                meta.format = "%d-%m-%Y";
            }

            if (typeof meta.numberOfMonths == 'undefined') {
                meta.numberOfMonths = [1, 1];
            }

            var datePickerOptions = {
                beforeShowDay: function(date) {
                    if (date >= highlightedDateMin && date < highlightedDateMax) {
                        return [true, 'widget-highlight', ''];
                    } else {
                        return [true, '', ''];
                    }
                },
                yearRange: '1900:2100',
                firstDay: 1,
                hideIfNoPrevNext: true,
                constrainInput: true,
                numberOfMonths: meta.numberOfMonths,
                dateFormat:
                    meta.format
                    .replace('%Y', 'yy')
                    .replace('%m', 'mm')
                    .replace('%d', 'dd'),
                duration: 0,
                onSelect: function() {
                    var meta = window.babAddonWidgets.getMetadata(this.id);

                    if (meta.to && jQuery('#'+meta.to).datepicker("getDate")) {
                        //jQuery('#'+meta.to).datepicker("setDate", )
                        todate = jQuery('#'+meta.to).datepicker("getDate");
                        var nextdate = jQuery(this).datepicker("getDate");
                        var previousdate = this.beforedate;

                        timedif = nextdate.getTime() - previousdate.getTime();

                        Math.trunc = Math.trunc || function(x) {
                            return x < 0 ? Math.ceil(x) : Math.floor(x);
                        };

                        nbdays = Math.trunc(timedif/(1000*60*60*24));

                        todate.setDate(todate.getDate()+nbdays);

                        var meta = window.babAddonWidgets.getMetadata(this.id);
                        if (meta.mindatey != null) {
                            mindate = new Date();
                            mindate.setYear(meta.mindatey);
                            mindate.setMonth(meta.mindatem -1);
                            mindate.setDate(meta.mindated);
                        } else {
                            mindate = null;
                        }
                        if (meta.maxdatey != null) {
                            maxdate = new Date();
                            maxdate.setYear(meta.maxdatey);
                            maxdate.setMonth(meta.maxdatem -1);
                            maxdate.setDate(meta.maxdated);
                        } else {
                            maxdate = null;
                        }

                        jQuery('#'+meta.to).datepicker("option", {
                                minDate: mindate==null ? meta.from	? jQuery('#'+meta.from).datepicker("getDate") 	: null : mindate,
                                maxDate: maxdate==null ? meta.to	? null/*jQuery('#'+meta.to).datepicker("getDate")*/ 	: null : maxdate
                        });

                        jQuery('#'+meta.to).datepicker("setDate", todate);
                    }


                },
                beforeShow: function() {
                    this.beforedate = jQuery(this).datepicker("getDate");
                    var meta = window.babAddonWidgets.getMetadata(this.id);
                    if (meta.mindatey != null) {
                        mindate = new Date();
                        mindate.setYear(meta.mindatey);
                        mindate.setMonth(meta.mindatem -1);
                        mindate.setDate(meta.mindated);
                    } else {
                        mindate = null;
                    }
                    if (meta.maxdatey != null) {
                        maxdate = new Date();
                        maxdate.setYear(meta.maxdatey);
                        maxdate.setMonth(meta.maxdatem -1);
                        maxdate.setDate(meta.maxdated);
                    } else {
                        maxdate = null;
                    }

                    return {
                            minDate: mindate==null ? meta.from	? jQuery('#'+meta.from).datepicker("getDate") 	: null : mindate,
                            maxDate: maxdate==null ? meta.to	? null/*jQuery('#'+meta.to).datepicker("getDate")*/ 	: null : maxdate
                    };

                }
            };
            if (typeof meta.showWeek != 'undefined') {
                datePickerOptions.showWeek = meta.showWeek;
            }
            if (typeof meta.dateClickUrl != 'undefined' && meta.dateClickUrl != '') {
                datePickerOptions.onSelect = function(dateText, inst) {
                    var dateClickUrl = meta.dateClickUrl.replace('__date__', dateText);
                    window.location.href = dateClickUrl;
                };
            }
            if (jQuery(this).hasClass('widget-datepicker-changeyear')) {
                datePickerOptions.changeYear = true;
            }
            if (jQuery(this).hasClass('widget-datepicker-changemonth')) {
                datePickerOptions.changeMonth = true;
            }

            jQuery(this)
                .addClass('widget-init-done')
                .datepicker(datePickerOptions)
                .attr('autocomplete', 'off');
        });
    }
}


jQuery(document).ready(function() {
    window.bab.initFunctions.push(widget_datePickerInit);
    widget_datePickerInit(document.getElementsByTagName("BODY")[0]);
});


