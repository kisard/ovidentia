
Timeline_ajax_url = bab_getInstallPath() + "skins/ovidentia/templates/addons/widgets/timeline/timeline_ajax/simile-ajax-api.js";
Timeline_urlPrefix = bab_getInstallPath() + "skins/ovidentia/templates/addons/widgets/timeline/timeline_js/";     
Timeline_parameters = "bundle=true";
