
function widget_formInit(domNode)
{
    window.onbeforeunload =	function(e) {
        var e = e || window.event;
        var ask = false;
        var message = '';
        
        jQuery('.widget-form').each(function (e) {
            if (this.checkUnsaved && this.isUnsaved) {
                var meta = window.babAddonWidgets.getMetadata(jQuery(this).attr('id'));
                message += meta.unsavedMessage + '\n' || '';
                ask = true;
            }
        });

        if (ask) {
            // For IE and Firefox
            if (e) {
                e.returnValue = message;
            }
            return message;
        }
    };


    jQuery(domNode).find('.widget-form')

    .each(
        function() {
            this.isUnsaved = false;
            if (window.babAddonWidgets.getMetadata(jQuery(this).attr('id')).checkUnsaved) {
                this.checkUnsaved = true;
                // We store the original values of the form.
                this.orginalValues = jQuery(this).serializeArray();
                var form = this;

                jQuery(this).change(function () {
                    var original = this.orginalValues;
                    var current = jQuery(this).serializeArray();

                    // We compare the original values and the current values of the form.
                    var isSame = (current.length == original.length) && current.every(function(element, index) {
                        return (element.name === original[index].name) && (element.value === original[index].value); 
                    });

                    form.isUnsaved = !isSame;
                });
            }

            if (jQuery(this).hasClass('widget-ajax')) {
                var meta = window.babAddonWidgets.getMetadata(jQuery(this).attr('id'));
                var eventName = meta.ajaxActionEvent;


                jQuery(this).bind(eventName, function(e) {
                    var ajaxOptions = {
                        success: function(response) {
                            if (meta.ajaxActionReload) {
                                var nbAjaxActionReload = meta.ajaxActionReload.length;
                                for (var i = 0; i < nbAjaxActionReload; i++) {
                                    var reloadedElement = document.getElementById(meta.ajaxActionReload[i]);
                                    if (reloadedElement) {
                                        window.babAddonWidgets.reload(reloadedElement);
                                    }
                                }
                            }
                        }
                    };

                    var method = jQuery(this).attr('method').toUpperCase();

                    ajaxOptions.method = method;
                    switch (method) {
                        case 'POST':
                            ajaxOptions.url = meta.ajaxAction;
                            ajaxOptions.data =  jQuery(this).serializeArray();
                            break;
                        case 'GET':
                        default:
                            var ajaxActionElements = meta.ajaxAction.split('?');
                            ajaxOptions.url = ajaxActionElements[0] + '?' + jQuery(this).serialize() + '&' + ajaxActionElements[1];
                            break;
                    }

                    jQuery.ajax(ajaxOptions);

                    //e.stopPropagation();
                    if (eventName == 'click') {
                        return false;
                    }
                });
            }
        }
    )

    .submit(
        function(event) {
            return widgets_validateSubmitForm(this);
        }
    );



    jQuery(domNode).find('.widget-form .widget-submitbutton').not('.widget-submitbutton-init-done').each(function() {

        jQuery(this).addClass('widget-submitbutton-init-done');



        if (jQuery(this).hasClass('widget-ajax')) {

            // The button submits the form through ajax.

            jQuery(this).click(function(e) {

                var form = jQuery(this).parents('form').get(0);
                form.isUnsaved = false;

                if (jQuery(this).hasClass('widget-submitbutton-mandatory')) {
                    window.babAddonWidgets.validate = true;
                    window.babAddonWidgets.validatemandatory = true;

                } else if (jQuery(this).hasClass('widget-submitbutton-validate')) {
                    window.babAddonWidgets.validate = true;
                    window.babAddonWidgets.validatemandatory = false;
                } else {
                    window.babAddonWidgets.validate = false;
                    window.babAddonWidgets.validatemandatory = false;
                }

                var submitButton = this;
                var meta = window.babAddonWidgets.getMetadata(jQuery(submitButton).attr('id'));
                var containingForm = jQuery(submitButton).closest('form');

                var submitValidate = widgets_validateSubmitForm(containingForm);
                if(!submitValidate){
                    return false;
                }

                jQuery(submitButton).closest('.ui-dialog-content').addClass('widget-delayed-action-loading');

                var ajaxOptions = {
                    success: function(response) {

                        // If the button submitted a form in a dialog, close the dialog.
                        if (jQuery(submitButton).hasClass('widget-no-close')) {
                            jQuery(submitButton).closest('.ui-dialog-content').removeClass('widget-delayed-action-loading');
                        } else if (jQuery(containingForm).attr('method').toLowerCase() == 'post'){
                            jQuery(submitButton)
                                .closest('.ui-dialog-content')
                                .removeClass('widget-delayed-action-loading')
                                .dialog('close');
                        }


                        if (meta.ajaxActionReload) {
                            var nbAjaxActionReload = meta.ajaxActionReload.length;
                            for (var i = 0; i < nbAjaxActionReload; i++) {
                                var reloadedElement = document.getElementById(meta.ajaxActionReload[i]);
                                if (reloadedElement) {
                                    window.babAddonWidgets.reload(reloadedElement);
                                }
                            }
                        }
                    }
                };

                var method = containingForm.attr('method').toUpperCase();

                ajaxOptions.method = method;
                switch (method) {
                    case 'POST':
                        ajaxOptions.url = meta.ajaxAction;
                        ajaxOptions.data =  containingForm.serializeArray();
                        break;
                    case 'GET':
                    default:
                        var ajaxActionElements = meta.ajaxAction.split('?');
                        ajaxOptions.url = ajaxActionElements[0] + '?' + containingForm.serialize() + '&' + ajaxActionElements[1];
                        break;
                }

                jQuery.ajax(ajaxOptions);

                //e.stopPropagation();
                return false;
            });

        } else {

            // The button does not submit the form through ajax.

            if (jQuery(this).hasClass('widget-popup')) {

                jQuery(this).click(function(e) {
                    bab_popup(jQuery(this).attr('href'));
                    e.stopPropagation();
                    return false;
                });

            }


            jQuery(this).click(function(event) {

                var form = jQuery(this).parents('form').get(0);
                form.isUnsaved = false;

                if (jQuery(this).hasClass('widget-submitbutton-mandatory')) {
                    window.babAddonWidgets.validate = true;
                    window.babAddonWidgets.validatemandatory = true;

                } else if (jQuery(this).hasClass('widget-submitbutton-validate')) {
                    window.babAddonWidgets.validate = true;
                    window.babAddonWidgets.validatemandatory = false;
                } else {
                    window.babAddonWidgets.validate = false;
                    window.babAddonWidgets.validatemandatory = false;
                }
            });

        }

    });







    jQuery(domNode).find('.widget-form').find('.widget-autosubmitonchange').change(function () {
        jQuery(this).parents('form').submit();
    });

    jQuery(domNode).find('.widget-form.widget-persistent').not('.widget-persistent-init-done').each(function() {

        jQuery(this).addClass('widget-persistent-init-done');

        if (widgets_haveFormData(this)) {
        	widgets_initFormData(this);
        } else {
        	// save of initial form data to allow reload of form parts via ajax
        	widgets_saveFormData(this);
        }

        jQuery(this).change(function () {
            if (!jQuery(this).hasClass('widget-persistent-inprogress')) {
                widgets_saveFormData(this);
            }
        });


        jQuery(this).submit(function () {
            widgets_clearFormData(this);
        });
    });


}


function widgets_validateSubmitForm(domnode)
{
    if (!window.babAddonWidgets.validate) {
        return true;
    }
    var canSubmit = true;
    var canSubmitId = [];
    var errorMessages = [];

    jQuery(domnode).find('.widget-filepicker.widget-filepicker-uploading').each(function() {
        jQuery(this).css('border', '1px solid red');
        if (window.babAddonWidgets.getMetadata(jQuery(this).attr('id')).waitUploadErrorMessage) {
            errorMessages.push(window.babAddonWidgets.getMetadata(jQuery(this).attr('id')).waitUploadErrorMessage);
        }
        canSubmitId[jQuery(this).attr('id')] = true;
        canSubmit = false;
    });

    jQuery(domnode).find('.widget-input-mandatory')
        .not('.widget-displaymode')
        .not('.widget-radioset')
        .not('.widget-userpicker')
        .not('.widget-multilanglineedit').each(function() {
        // Do not validate inputs inside a widget-discarded element.
        if (jQuery(this).parents('.widget-discarded').length > 0) {
            return;
        }

        val = jQuery(this).val() === '';
        borderItem = jQuery(this);
        if(jQuery(this).hasClass('widget-multiselect')) {
            val = jQuery(this).val() === null;
            borderItem = jQuery(this).parent().find('button');
        } else if (jQuery(this).hasClass('widget-checkbox')) {
            val = !jQuery(this).is(':checked');
        } else if (jQuery(this).hasClass('widget-filepicker')) {
            val = jQuery(this).find('.widget-filepicker-file').size() == 0;
        } else if (jQuery(this).hasClass('widget-hidden-suggest')) {
            borderItem = jQuery(window.babAddonWidgets.getMetadata(jQuery(this).attr('id')).parent_id);
        } else if (jQuery(this).hasClass('widget-simplehtmledit')) {
            borderItem = jQuery(this).parent().find('.wysiwyg');
        }

        if (val && jQuery(this).attr('id')) {
            borderItem.addClass('widget-rejected');
            if (window.babAddonWidgets.getMetadata(jQuery(this).attr('id')).mandatoryErrorMessage) {
                errorMessages.push(window.babAddonWidgets.getMetadata(jQuery(this).attr('id')).mandatoryErrorMessage);
            }
            canSubmitId[jQuery(this).attr('id')] = true;
            canSubmit = false;
        } else {
            borderItem.removeClass('widget-rejected');
        }
    });

    jQuery(domnode).find('.widget-timepicker').each(function() {
        // Do not validate inputs inside a widget-discarded element.
        if (jQuery(this).parents('.widget-discarded').length > 0) {
            return;
        }

        var time = jQuery(this).val();
        if (time === '') {
            return 0;
        }
        var values = time.split(':');
        if (values.length != 2) {
            jQuery(this).css('border', '1px solid red');
            errorMessages.push("Format d'heure non valide.");
            canSubmitId[jQuery(this).attr('id')] = true;
            canSubmit = false;
        } else {
            var hours = parseInt(values[0]);
            var minutes = parseInt(values[1]);
            if (isNaN(hours) || isNaN(minutes) || hours < 0 || hours > 23 || minutes < 0 || minutes > 59 ) {
                jQuery(this).css('border', '1px solid red');
                errorMessages.push("Format d'heure non valide.");
            } else {
                jQuery(this).css('border', '');
            }
        }
    });

    jQuery(domnode).find('.widget-input-ajax-validate').not('.widget-displaymode').not('.widget-radioset').filter(":visible").each(function() {
        if (jQuery(this).val() !== '' && jQuery(this).parents('.widget-discarded').length <= 0) {
            var validateInput = jQuery(this);
            var url = window.babAddonWidgets.getMetadata(validateInput.attr('id')).ajaxValidateAction;
            jQuery.ajax({
                url: url,
                dataType: 'html',
                data: { value: validateInput.val() },
                cache: false,
                async: false,
                success: function(response) {
                    if (response === '1') {
                        validateInput.css('border', '');
                        validateInput.addClass('widget-valid');
                        validateInput.removeClass('widget-invalid');
                    } else {
                        try {
                            response = jQuery.parseJSON(response);
                            if (response.status === 'OK') {
                                validateInput.css('border', '');
                                validateInput.attr('title', response.info);
                                validateInput.addClass('widget-valid');
                                validateInput.removeClass('widget-invalid');
                            }
                        } catch (e) {
                            canSubmit = false;
                            validateInput.css('border', '1px solid darkorange');
                            validateInput.addClass('widget-invalid');
                            validateInput.removeClass('widget-valid');
                            validateInput.attr('title', '');
                            errorMessages.push(response);
                        }
                    }
                }
            });

        } else {
            if(typeof canSubmitId[jQuery(this).attr('id')] == "undefined"){
                jQuery(this).css('border', '');
            }
        }
    });

    if (errorMessages.length > 0) {
        alert(errorMessages.join("\n"));
    }



    return canSubmit;
}



/**
 * 
 * @param form
 * @returns {Boolean}
 */
function widgets_haveFormData(form) {
	
	form = jQuery(form);
	var key;
    for (var i = 0; i < localStorage.length; i++) {
         key = localStorage.key(i);
         var pathStart = form.attr('id') + '/';
         if (key.substr(0, pathStart.length) == pathStart) {
             return true;
         }
    }
    
    return false;
}


/**
 * Fill form with saved data
 * @param form
 */
function widgets_initFormData(form) {
    jQuery(form).addClass('widget-persistent-inprogress');
    jQuery(form).find('input,textarea,select').not('.widget-multiselect').not('.widget-checkbox-hidden').each(function() {
        var inputName = jQuery(this).attr('name');
        if (inputName !== undefined) {
            var key = form.id + '/' + inputName;
            var value = false;
            if (jQuery(form).hasClass('widget-local-storage')) {
                value = localStorage.getItem(key);
            } else if (jQuery(form).hasClass('widget-session-storage')) {
                value = sessionStorage.getItem(key);
                if (value == null) {//INIT session storage
                    value = jQuery(this).val();
                    if (jQuery(this).attr('type') == "checkbox" || jQuery(this).attr('type') == "radio") {
                        if (jQuery(this).is(':checked')) {
                            value = 1;
                        } else {
                            value = 0;
                        }
                    }
                    sessionStorage.setItem(key, value);
                }
            }
			//console.debug(inputName+ ' => '+value);
            if (value !== null) {
                if( jQuery(this).attr('type') == "checkbox" || jQuery(this).attr('type') == "radio") {
                    if (value && value != '0') {
                        jQuery(this).attr('checked', true);
                    } else {
                        jQuery(this).removeAttr('checked');
                    }
                } else {
                    jQuery(this).val(value);
                }
                jQuery(this).change();
            }
        }
    });
    jQuery(form).removeClass('widget-persistent-inprogress');
}


function widgets_saveFormData(form) {
    jQuery(form).find('input,textarea,select').not('.widget-multiselect').not('.widget-checkbox-hidden').each(function() {
        var inputName = jQuery(this).attr('name');
        if (inputName !== undefined) {
            var key = form.id + '/' + inputName;
            var value = jQuery(this).val();
            if (jQuery(this).attr('type') == "checkbox" || jQuery(this).attr('type') == "radio") {
                if (jQuery(this).is(':checked')) {
                    value = 1;
                } else {
                    value = 0;
                }
            }
            if (jQuery(form).hasClass('widget-local-storage')) {
                localStorage.setItem(key, value);
            } else if (jQuery(form).hasClass('widget-session-storage')) {
                sessionStorage.setItem(key, value);
            }
            //console.log(key + ':' + value);
        }
    });
}


function widgets_clearFormData(form) {
    var key;
    for (var i = 0; i < localStorage.length; ) {
         key = localStorage.key(i);
         var pathStart = form.id + '/';
         if (key.substr(0, pathStart) == pathStart) {
             if (jQuery(form).hasClass('widget-local-storage')) {
                 localStorage.removeItem(key);
             } else if (jQuery(form).hasClass('widget-session-storage')) {
                 sessionStorage.removeItem(key);
             }
         } else {
             i++;
         }
    }
}


window.bab.addInitFunction(widget_formInit);


