// need jquery 1.7.1.3 module with the lightbox jquery plugin


window.bab.addInitFunction(function() {
	
	if (typeof jQuery('.widget-imagezoomer').lightBox != 'function')
	{
		return;
	}
	
	jQuery('.widget-imagezoomer').lightBox();
});

