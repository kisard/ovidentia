<?php
//-------------------------------------------------------------------------
// OVIDENTIA http://www.ovidentia.org
// Ovidentia is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2, or (at your option)
// any later version.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
// USA.
//-------------------------------------------------------------------------
/**
 * @license http://opensource.org/licenses/gpl-license.php GNU General Public License (GPL)
 * @copyright Copyright (c) 2008 by CANTICO ({@link http://www.cantico.fr})
 */


/**
 * Manage addons informations for multiples addons
 */
class bab_addonsInfos {

	private $indexById 			= array();
	private $indexByName 		= array();
	private $fullIndexById		= array();
	private $fullIndexByName	= array();

	private static $instance = null;


	/**
	 * Get accessible status and update table if necessary
	 * @param	int		$id_addon
	 * @param	string	$title		Addon name
	 * @param	string	$version	Database addon version
	 * @param	string	$installed	Y|N
	 * @param	string	$enabled	Y|N
	 * @return boolean
	 */
	private static function isAccessible($id_addon, $title, $version, $installed, $enabled)
	{
        return true;
	}



	/**
	 * Create indexes with access rights verification
	 * @return boolean
	 */
	private function createIndex()
	{
		return true;
	}



	/**
	 * Create full index of addons with disabled and not installed addons
	 * @return boolean
	 */
	private function createFullIndex()
	{
	    return true;
	}


	private static function getInstance()
	{
		return bab_getInstance('bab_addonsInfos');
	}



	/**
	 * Get available addons indexed by id
	 * since $babBody->babaddons is deprecated, this method has the same result
	 * @return array
	 */
	public static function getRows()
	{
	}


	/**
	 * Get addon row from installed and enabled addons list
	 * @param	int	$id_addon
	 * @return	false|array
	 */
	public static function getRow($id_addon)
	{
	}


	/**
	 * Get all addons indexed by id
	 * @return array
	 */
	public static function getDbRows()
	{
	}


	/**
	 * Get all addons rows indexed by name
	 * @return array
	 */
	public static function getDbRowsByName()
	{
	}

	/**
	 * Get all addons objects indexed by name
	 * @return array	of bab_addonInfos
	 * @see bab_addonInfos
	 */
	public static function getDbAddonsByName()
	{
	}


	/**
	 * Get addon row if exist, from all addons in table
	 * @param	int	$id_addon
	 * @return	false|array
	 */
	public static function getDbRow($id_addon)
	{
	}



	/**
	 * Clear cache for addons
	 */
	public static function clear()
	{
	}



	/**
	 * Get addon id by name
	 *
	 * @param	string	$name
	 * @param	boolean	$access_rights
	 *
	 * @return int|false
	 */
	public static function getAddonIdByName($name, $access_rights = true)
	{
	}






	/**
	 * Browse addons folder and add missing addons to bab_addons
	 */
	public static function insertMissingAddonsInTable()
	{
	}
}







/**
 * Manage addon informations for one addon
 * @since 6.6.93
 */
class bab_addonInfos {

	/**
	 * @access private
	 */
	var $id_addon;

	/**
	 * @access private
	 */
	var $addonname;

	/**
	 * @access private
	 */
	var $ini = null;

	/**
	 *
	 * @var array
	 */
	private $tags;


	/**
	 * Set addon Name
	 * This function verifiy if the addon is accessible
	 * define $this->id_addon and $this->addonname
	 * @see bab_getAddonInfosInstance() this method is used for the creation of the instance with acces_rights=false
	 *
	 * @param	string	$addonname
	 * @param	boolean	$access_rights	: access rights verification on addon
	 * @return boolean
	 */
	public function setAddonName($addonname, $access_rights = true)
	{

		$id_addon = bab_addonsInfos::getAddonIdByName($addonname, $access_rights);

		if (false === $id_addon) {
			return false;
		}

		if ($access_rights) {
			if (!bab_isAddonAccessValid($id_addon)) {
				return false;
			}
		}

		$this->id_addon = $id_addon;
		$this->addonname = $addonname;

		return true;
	}



	/**
	 * Get the addon name
	 * a replacement for $babAddonFolder
	 * @return string
	 */
	public function getName()
	{
		return $this->addonname;
	}

	/**
	 * get the addon ID
	 * @return int
	 */
	public function getId()
	{
		return (int) $this->id_addon;
	}


	/**
	 * a replacement for $babAddonTarget
	 * @return string
	 */
	public function getTarget()
	{
		return "addon/".$this->id_addon;
	}

	/**
	 * a replacement for $babAddonUrl
	 * @return string
	 */
	public function getUrl()
	{
		global $babUrlScript;
		return $babUrlScript.'?tg=addon%2F'.$this->id_addon.'%2F';
	}

	/**
	 *
	 * a replacement for $babAddonHtmlPath
	 * @return string
	 */
	public function getRelativePath()
	{
		return 'addons/'.$this->addonname.'/';
	}

	/**
	 * a replacement for $babAddonPhpPath
	 * @return string
	 */
	public function getPhpPath()
	{
		return dirname(__FILE__) . '/../../programs';
	}

	/**
	 * Get the addon upload path
	 * a replacement for $babAddonUpload
	 * @return string
	 */
	public function getUploadPath()
	{
		return '/tmp';
	}

	/**
	 * Get path to template directory
	 * @return string
	 */
	public function getTemplatePath()
	{
		return dirname(__FILE__) . '/../../skins/ovidentia/templates/';
	}


	/**
	 * Get path to images directory
	 * @return string
	 */
	public function getImagesPath()
	{
		return dirname(__FILE__) . '/../../skins/ovidentia/images/';
	}


	/**
	 * Get path to ovml directory
	 * @return string
	 */
	public function getOvmlPath()
	{
		return dirname(__FILE__) . '/../../skins/ovidentia/ovml/';
	}


	/**
	 * Get path to css stylesheets directory
	 * @return string
	 */
	public function getStylePath()
	{
		return dirname(__FILE__) . '/../../styles/';
	}

	/**
	 * Get path to translation files directory
	 * @return string
	 */
	public function getLangPath()
	{
		return dirname(__FILE__) . '/../../langfiles/';
	}


	/**
	 * get INI object, general section only
	 * @return bab_inifile
	 */
	public function getIni()
	{
		if (null === $this->ini) {
			include_once $GLOBALS['babInstallPath'].'utilit/inifileincl.php';
			$this->ini = new bab_inifile();
			$inifile = $this->getPhpPath().'addonini.php';

			if (!is_readable($inifile)) {
				throw new Exception(sprintf('Error, the file %s must be readable', $inifile));
			}

			if (!$this->ini->inifileGeneral($inifile)) {
				throw new Exception(sprintf('Error, the file %s is missing or has syntax errors', $inifile));
			}
		}

		return $this->ini;
	}


	/**
	 * Check validity of addon INI file requirements
	 * @return boolean
	 */
	public function isValid()
	{
		return true;
	}


	/**
	 * Get configuration url or null if no configuration page defined
	 * @return string
	 */
	public function getConfigurationUrl()
	{
		return '';
	}



	/**
	 * addon has global access control
	 * @return boolean
	 */
	public function hasAccessControl()
	{
		return true;
	}





	/**
	 * Get the type of addon.
	 * The addon type can be EXTENSION | LIBRARY | THEME
	 *
	 * @return string
	 */
	public function getAddonType()
	{
		return 'LIBRARY';
	}



	/**
	 * addon is deletable by administrator
	 * @return boolean
	 */
	public function isDeletable()
	{
		return true;
	}

	/**
	 * is addon installed by administrator
	 * @return boolean
	 */
	public function isInstalled()
	{
		return true;
	}


	/**
	 * is addon disabled by administrator
	 * @return boolean
	 */
	public function isDisabled()
	{
		return false;
	}

	/**
	 * Disable addon
	 * @return bab_addonInfos
	 */
	public function disable()
	{
		return $this;
	}


	/**
	 * Enable addon
	 * @return bab_addonInfos
	 */
	public function enable()
	{
		return $this;
	}


	/**
	 * Get version from ini file
	 * @return string
	 */
	public function getIniVersion() {

		$ini = $this->getIni();
		return $ini->getVersion();
	}


	/**
	 * Get description from ini file
	 * @return string
	 */
	public function getDescription() {

		$ini = $this->getIni();

		if (false === $ini->fileExists()) {
			return bab_translate('Error, the files of addon are missing, please delete the addon or restore the orginal addon folders');
		}

		return $ini->getDescription();
	}







	/**
	 * get version from database
	 * @return string
	 */
	public function getDbVersion() {
		$arr = bab_addonsInfos::getDbRow($this->id_addon);
		return $arr['version'];
	}

	/**
	 * Test if the addon need an upgrade of the database
	 * @return bool
	 */
	public function isUpgradable()
	{
		return true;
	}


	/**
	 * Test if addon is accessible
	 * if access control, and addons access rights verification return false, addon is not accessible
	 * if addons is disabled, the addons is not accessible
	 * if addon is not installed, addon is not accessible
	 * @return boolean
	 */
	public function isAccessValid()
	{
        return true;
	}

	/**
	 * Verify addon installation status
	 * after addon files has been modified, this method update the table with new installation status
	 * @return boolean
	 */
	public function updateInstallStatus()
	{
		return true;
	}




	/**
	 *
	 * @return	boolean
	 */
	private function setDbVersion($version)
	{
		return true;
	}


	/**
	 * Get the list of tables associated to addon
	 * from db_prefix in addon ini file
	 * @return array
	 */
	public function getTablesNames()
	{
		$tbllist = array();
		return $tbllist;
	}



	/**
	 * Return the image path
	 * a 200x150px png, jpg or gif image, representation of the addon
	 * @return string|null
	 */
	public function getImagePath()
	{
		$ini = $this->getIni();

		if (!isset($ini->inifile['image'])) {
			return null;
		}

		$imgpath = $this->getImagesPath().$ini->inifile['image'];

		if (!is_file($imgpath)) {
			return null;
		}


		return $imgpath;
	}



	/**
	 * Return the icon path
	 * a 48x48px png, jpg or gif image, representation of the addon
	 * @return string|null
	 */
	public function getIconPath()
	{
		$ini = $this->getIni();

		switch ($this->getAddonType()) {
			case 'THEME':
				$default = $GLOBALS['babSkinPath'].'images/48x48/apps/addon-theme.png';
				break;
			case 'LIBRARY':
				$default = $GLOBALS['babSkinPath'].'images/48x48/apps/addon-library.png';
				break;
			case 'EXTENSION':
			default:
				$default = $GLOBALS['babSkinPath'].'images/48x48/apps/addon-extension.png';
				break;
		}
//		$default = $GLOBALS['babSkinPath'].'images/48x48/apps/addon-default.png';

		if (!isset($ini->inifile['icon'])) {
			return $default;
		}

		$imgpath = $this->getImagesPath().$ini->inifile['icon'];

		if (!is_file($imgpath)) {
			return $default;
		}


		return $imgpath;
	}


	/**
	 * Call upgrade function of addon
	 * @return boolean
	 */
	public function upgrade()
	{
		return true;
	}




	/**
	 * remove obsolete lines in tables
	 * @return bool
	 */
	private function deleteInTables()
	{
		return true;
	}



	/**
	 * Remove addon
	 * @param	string	&$msgerror
	 * @return boolean
	 */
	public function delete(&$msgerror)
	{
        return true;
	}



	/**
	 * list of addons used by the current addon
	 * @return	array	in the key, the name of the addon, in the value a boolean for dependency satisfaction status
	 */
	public function getDependencies()
	{
		$return = array();
		return $return;
	}



	/**
	 * list of addons that use the current addon
	 * @return	array	in the key, the name of the addon, in the value a boolean for dependency satisfaction status
	 */
	public function getDependences()
	{
		$return = array();
		return $return;
	}

	/**
	 * get all dependencies for addon
	 * @param	bab_OrphanRootNode	$root
	 * @param	string				$parent
	 * @return bool
	 */
	private function getRecursiveDependencies(bab_OrphanRootNode $root, $nodeId = 'root', $parent = null)
	{
		return true;
	}


	private function browseRecursiveDependencies(&$stack, bab_Node $node)
	{
	}


	/**
	 * Get all dependencies for addons sorted in install order
	 * the value and key in array is the addon name
	 *
	 * @return array
	 */
	public function getSortedDependencies()
	{
		return array();
	}


	/**
	 * Get all dependencies for addons sorted in install order
	 * if the main addon specify a "pakage" configuration string, use it instead of the getSortedDependencies method
	 * the value and key in array is the addon name
	 *
	 * @return array
	 */
	public function getPackageDependencies()
	{
		return $this->getSortedDependencies();
	}



	/**
	 * Test if the addon is compatible with the specified charset
	 * @param	string	$isoCharset
	 * @boolean
	 */
	public function isCharsetCompatible($isoCharset)
	{
		return true;
	}


	/**
	 * Get tags list associated to addons
	 * @return array
	 */
	public function getTags()
	{
		$this->tags = array();
		return $this->tags;
	}

	/**
	 * Test if a tag exists in addon
	 * if $tag is an array, return true if all tags are found in the addon
	 *
	 * @param string | array $tag
	 * @return bool
	 */
	public function hasTag($tag)
	{
		return false;
	}
}