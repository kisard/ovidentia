<?php


$GLOBALS['babInstallPath'] = dirname(__FILE__) . '/';


if (!defined('FUNC_WIDGETS_PHP_PATH')) {
    define('FUNC_WIDGETS_PHP_PATH', realpath(dirname(__FILE__) . '/../../programs/widgets') . '/');
}
if (!defined('FUNC_WIDGETS_JS_PATH')) {
    define('FUNC_WIDGETS_JS_PATH', realpath(dirname(__FILE__) . '/../../programs/skins/ovidentia/templates') . '/');
}

/**
 * @return Func_Widgets
 */
function bab_Widgets()
{
    require_once dirname(__FILE__) . '/../../programs/widgets.php';
    return bab_getInstance('Func_Widgets');
}


class Func_JQuery
{

    public function __call($name, $args)
    {
        return $name;
    }
}

function bab_jQuery()
{
    return new Func_JQuery();
}


function bab_translate($text)
{
//     if ($text === ':') {
//         return ' :';
//     }
    return $text;
}


class bab_charset
{
    private static $sCharset = null;
    private static $sIsoCharset = null;

    /**
     * UTF-8 encoding.
     *
     * @var string
     */
    const	UTF_8 = 'UTF-8';

    /**
     * ISO-8859-15 (latin1) encoding.
     *
     * @var string
     */
    const	ISO_8859_15 = 'ISO-8859-15';

    /**
     * Returns the database charset
     *
     * @static
     * @return   string	The database charset
     */
    public static function getDatabase()
    {
        self::$sCharset = 'latin1';
        return self::$sCharset;
    }

    private static function resetCharset()
    {
        self::$sCharset = null;
        bab_charset::getDatabase();
    }


    /**
     * Returns the ISO code of the database encoding.
     *
     * @return string
     */
    public static function getIso()
    {
        if(!isset(self::$sIsoCharset)) {
            self::$sIsoCharset = self::getIsoCharsetFromDataBaseCharset(self::getDatabase());
        }
        return self::$sIsoCharset;
    }

    /**
     * Converts the code of the database encoding to the ISO code.
     *
     * @param string $sCharset The charset code as returned by bab_charset::getDatabase().
     *
     * @return string
     */
    public static function getIsoCharsetFromDataBaseCharset($sCharset)
    {
        switch($sCharset)
        {
            case 'utf8':
                return self::UTF_8;

            case 'latin1':
                return self::ISO_8859_15;

            default:
                return '';
        }
    }
}


define('BAB_HTML_ENTITIES'		,1);
define('BAB_HTML_P'				,BAB_HTML_ENTITIES << 1);
define('BAB_HTML_BR'			,BAB_HTML_ENTITIES << 2);
define('BAB_HTML_LINKS'			,BAB_HTML_ENTITIES << 3);
define('BAB_HTML_AUTO'			,BAB_HTML_ENTITIES << 4);
define('BAB_HTML_JS'			,BAB_HTML_ENTITIES << 5);
define('BAB_HTML_REPLACE'		,BAB_HTML_ENTITIES << 6);
define('BAB_HTML_REPLACE_MAIL'	,BAB_HTML_ENTITIES << 7);
define('BAB_HTML_TAB'			,BAB_HTML_ENTITIES << 8);
define('BAB_HTML_ALL'			,BAB_HTML_ENTITIES | BAB_HTML_P | BAB_HTML_BR | BAB_HTML_LINKS | BAB_HTML_TAB);

function bab_toHtml($str, $option = BAB_HTML_ENTITIES)
{
	include_once dirname(__FILE__).'/utilit/tohtmlincl.php';
	return bab_f_toHtml($str, $option);
}





class bab_functionality
{
    /**
     * @return bab_functionality
     */
	public static function get($path, $singleton = true)
	{
        return new bab_functionality();
	}

	public static function includefile($path)
	{

	}
}



/**
 * Returns a singleton of the specified class.
 *
 * @param string $classname
 * @return object
 */
function bab_getInstance($classname)
{
    static $instances = NULL;

    if (is_null($instances)) {
        $instances = array();
    }
    if (!array_key_exists($classname, $instances)) {
        $instances[$classname] = new $classname();
    }

    return $instances[$classname];
}



/**
 * Generate a pseudo-random UUID according to RFC 4122
 *
 * @return string the new UUID
 */
function bab_uuid()
{
    return sprintf( '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
}



function bab_getAddonInfosInstance($addonname) {

	require_once $GLOBALS['babInstallPath'].'utilit/addonsincl.php';
	static $instances = array();

	if (false === array_key_exists($addonname, $instances)) {
		$obj = new bab_addonInfos();
		if (false === $obj->setAddonName($addonname, false)) {
			$instances[$addonname] = false;
		} else {
			$instances[$addonname] = $obj;
		}
	}
	return $instances[$addonname];
}



function bab_requireOnce($pathname)
{
    require_once dirname(__FILE__) . '/' . $pathname;
}


function bab_getUserInfos($id_user)
{
    return false;
    return $infos;
}

/**
 * return non breaking space
 * @return string
 */
function bab_nbsp()
{
    // return this fixed value for test
    return chr(160);
}


/**
 * Returns a unix timestamp corresponding to the string $time formatted as a MYSQL DATETIME
 *
 * @access  public
 *
 * @param   string	$time	(eg. '2006-03-10 17:37:02')
 *
 * @return  int	unix timestamp
 */
function bab_mktime($time)
{
    $arr = explode(" ", $time); //Split days and hours
    if ('0000-00-00' == $arr[0] || '' == $arr[0]) {
        return null;
    }
    $arr0 = explode("-", $arr[0]); //Split year, month et day
    if (isset($arr[1])) { //If the hours exist we send back days and hours
        $arr1 = explode(":", $arr[1]);
        return mktime($arr1[0], $arr1[1], $arr1[2], $arr0[1], $arr0[2], $arr0[0]);
    } else { //If the hours do not exist, we send back only days
        return mktime(0, 0, 0, $arr0[1], $arr0[2], $arr0[0]);
    }
}



/**
 * Returns a string containing the time formatted according to the user's preferences
 *
 * @access  public
 * @return  string	formatted time
 * @param   int	$time	unix timestamp
 * @param   boolean $hour	(true == '17/03/2006',
 *							false == '17/03/2006 10:11'
 */
function bab_shortDate($time, $hour = true)
{
    if (null === $time) {
        return '';
    }

    return date('d/m/Y' . ($hour? ' H:i' : ''), $time);
}

function bab_getLanguage()
{
    return 'fr_FR';
}



/*
 * Get the name of the PHP file of script curently executed (default : index.php)
 *
 * @return string
 */
function bab_getSelf()
{
    return 'index.php';
}



/**
 * Request param
 * @since 6.0.6
 * @param string $name
 * @param mixed	$default
 * @return mixed
 */
function bab_rp($name, $default = '')
{
    if (isset($_GET[$name])) {
        return $_GET[$name];
    }
    if (isset($_POST[$name])) {
        return $_POST[$name];
    }
    return $default;
}

/**
 * Post param
 * @since 6.0.6
 * @param string $name
 * @param mixed	$default
 * @return mixed
 */
function bab_pp($name, $default = '')
{
    if (isset($_POST[$name])) {
        return $_POST[$name];
    }
    return $default;
}

/**
 * Get param
 * @since 6.0.6
 * @param string $name
 * @param mixed	$default
 * @return mixed
 */
function bab_gp($name, $default = '')
{
    if (isset($_GET[$name])) {
        return $_GET[$name];
    }
    return $default;
}


/**
 * Get ovidentia groups
 * The returned groups are stored in an array with three keys : id, name, description
 * in each keys, a list of group is stored with ordered numeric keys
 * the default value for the $all parameter is true
 *
 * @param	int			$parent		parent group in tree | if $parent is null, return the list of group sets
 * @param	boolean		$all		return one level of groups or groups from all sublevels
 * @return	array
 */
function bab_getGroups($parent = 1, $all = true)
{
    if (null === $parent) {
        $arr = array();
        return $arr;
    }

    $arr = array();

    return $arr;
}


function bab_getCurrentAdmGroup()
{
    return 0;
}


function bab_getCssUrl()
{
    return '';
}



function bab_getActiveSessions($id_user = null)
{
    return array();
}
