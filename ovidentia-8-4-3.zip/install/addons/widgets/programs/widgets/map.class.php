<?php
//-------------------------------------------------------------------------
// OVIDENTIA http://www.ovidentia.org
// Ovidentia is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2, or (at your option)
// any later version.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
// USA.
//-------------------------------------------------------------------------
/**
 * @license http://opensource.org/licenses/gpl-license.php GNU General Public License (GPL)
 * @copyright Copyright (c) 2006 by CANTICO ({@link http://www.cantico.fr})
 */
//include_once 'base.php';


require_once dirname(__FILE__) . '/boxlayout.class.php';


/**
 * Constructs a Widget_Map.
 *
 * @param string $id	The item unique id.
 * @return Widget_Map
 */
function Widget_Map($id = null)
{
	return new Widget_Map($id);
}


class Widget_Map extends Widget_Item implements Widget_Displayable_Interface
{
	private $width = 600;
	private $height = 450;
	private $mapType = 'google';
	private $openerList = array();
	private $marker = array();

	
	/**
	 * @param string $id	The item unique id.
	 * @return Widget_VBoxLayout
	 */
	public function __construct($id = null)
	{
		parent::__construct($id);
		$this->setMapFrom();
		$this->setZoom();
		
		return $this;
	}
	
	/**
	 */
	public function setMapFrom($mapFrom = 'google')
	{
		$this->setMetadata('mapFrom', $mapFrom);
		$this->mapType = $mapFrom;
		
		return $this;
	}
	
	/**
	 */
	public function setCenter($lat, $long)
	{
		$this->setMetadata('center', array('lat' => $lat, 'long' => $long));
		
		return $this;
	}
	
	/**
	 */
	public function setZoom($zoom = 16)
	{
		$this->setMetadata('zoom', $zoom);
		
		return $this;
	}
	
	/**
	 */
	public function addMarker($lat, $long, $name, Widget_Displayable_Interface $widget)
	{
		$this->marker[] = array('lat'=>$lat, 'long'=>$long, 'name'=>$name, 'widget'=>$widget);
		
		return $this;
	}
	
	/**
	 */
	public function setWidth($width = 600)
	{
		$this->width = $width;
		
		return $this;
	}
	
	/**
	 */
	public function setHeight($height = 450)
	{
		$this->height = $height;
		
		return $this;
	}
	
	public function addMarkerOpener($id, Widget_Displayable_Interface $widget)
	{
		$this->openerList[] = array('id' => $id, 'widget' => $widget);
		
		return $this;
	}


	public function getClasses()
	{
		$classes = parent::getClasses();
		$classes[] = 'widget-map';
		return $classes;
	}

	public function getAllMetadata(Widget_Canvas $canvas)
	{
		$metadata = parent::getMetadata();
		if(!empty($this->marker)){
			$metadata['marker'] = $this->marker;
			foreach($metadata['marker'] as $id => $marker){
				$metadata['marker'][$id]['id'] = $marker['widget']->getId();
				$metadata['marker'][$id]['widget'] = $marker['widget']->display($canvas);
			}
		}
		if(!empty($this->openerList)){
			foreach($this->openerList as $opener){
				$metadata['openerList'][$opener['id']][] = $opener['widget']->getId();
			}
		}
		return $metadata;
	}

	public function display(Widget_Canvas $canvas)
	{
		
		return $canvas->map(
			$this->getId(),
			$this->getClasses(),
			$this->width,
			$this->height,
			$this->getCanvasOptions(),
		    $this->getTitle(),
			$this->getAttributes()
		).$canvas->metadata($this->getId(), $this->getAllMetadata($canvas))
		.$canvas->loadScript($this->getId(), bab_getAddonInfosInstance('widgets')->getTemplatePath().'widgets.map.jquery.js');
	}
}
