<?php
//-------------------------------------------------------------------------
// OVIDENTIA http://www.ovidentia.org
// Ovidentia is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2, or (at your option)
// any later version.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
// USA.
//-------------------------------------------------------------------------
/**
 * @license http://opensource.org/licenses/gpl-license.php GNU General Public License (GPL)
 * @copyright Copyright (c) 2006 by CANTICO ({@link http://www.cantico.fr})
 */

require_once dirname(__FILE__) . '/checkbox.class.php';




/**
 * Constructs a Widget_CheckBox.
 *
 * @param string $id			The item unique id.
 * @return Widget_CheckBox
 */
function Widget_CheckBoxAll($id = null)
{
	return new Widget_CheckBoxAll($id);
}


/**
 * Check or uncheck a list of checkbox
 *
 */
class Widget_CheckBoxAll extends Widget_CheckBox implements Widget_Displayable_Interface
{

    
    /**
     * Add one checkbox to the group
     */
    public function addCheckBox(Widget_CheckBox $checkbox)
    {
        $group = $this->getMetadata('group');
        if (!isset($group)) {
            $group = array();
        }
        $group[] = $checkbox->getId();
        $this->setMetadata('group', $group);
    }
    
    /**
     * Add all found checkboxes
     * @param Widget_ContainerWidget|Widget_Layout $container
     * @return array
     */
    public function findCheckboxes($container)
    {

        
        if ($container instanceof Widget_ContainerWidget) {
            $layout = $container->getLayout();
        } else {
            $layout = $container;
        }
        
        if (null === $layout) {
            throw new Exception('The layout of the containerWidget "'.get_class($container).'" must not be null');
        }
        
        foreach ($layout->getItems() as $item) {
            if ($item instanceof Widget_CheckBox) {
                $this->addCheckBox($item);
            } elseif ($item instanceof Widget_ContainerWidget || $item instanceof Widget_Layout) {
                $this->findCheckboxes($item);
            }
        }

        return $this;
    }
    
    
    public function getClasses()
    {
        $classes = parent::getClasses();
        $classes[] = 'widget-checkboxall';
        return $classes;
    }
    
    
    
    public function display(Widget_Canvas $canvas)
    {
        $addon = bab_getAddonInfosInstance('widgets');
        
        return parent::display($canvas).$canvas->loadScript(
            $this->getId(),
            $addon->getTemplatePath().'widgets.checkboxall.jquery.js'
        );
    }

}