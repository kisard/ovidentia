<?php
//-------------------------------------------------------------------------
// OVIDENTIA http://www.ovidentia.org
// Ovidentia is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2, or (at your option)
// any later version.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
// USA.
//-------------------------------------------------------------------------
/**
 * @license http://opensource.org/licenses/gpl-license.php GNU General Public License (GPL)
 * @copyright Copyright (c) 2006 by CANTICO ({@link http://www.cantico.fr})
 */

require_once dirname(__FILE__) . '/tableview.class.php';
require_once dirname(__FILE__) . '/submitbutton.class.php';


/**
 * @param string | ORM_Field $field
 * @param string $description
 *
 * @return widget_TableModelViewColumn
 */
function widget_TableModelViewColumn($field, $description)
{
    if (null === $field) {
        return null;
    }

    return new widget_TableModelViewColumn($field, $description);
}



/**
 * A class used to define the content and the properties of a
 * TableModelView column.
 */
class widget_TableModelViewColumn
{
    private $field;
    private $fieldPath;
    private $description;

    private $visible = true;
    private $sortable = true;
    private $inList = true;
    private $exportable = true;
    private $searchable = true;
    private $selectable = true;
    private $selectableName = null;

    private $classes = array();

    public function __construct($field, $description)
    {
        if ($field instanceof ORM_Field) {
            $this->field = $field;
            $this->fieldPath = $field->getPath();
            if ($field instanceof ORM_NumericField && !($field instanceof ORM_UserField)) {
                $this->addClass('widget-align-right');
            }
        } else {
            $this->field = null;
            $this->fieldPath = $field;
        }

        $this->description = $description;


    }


    /**
     * @return ORM_Field
     */
    public function getField()
    {
        return $this->field;
    }

    /**
     * @return string
     */
    public function getFieldPath()
    {
        return $this->fieldPath;
    }


    /**
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }


    /**
     * Sets the column visibility.
     * If $visible is false, the column will be hidden, but if
     * column selection is allowed, the user will be able to make
     * it visible.
     *
     * @param bool $visible
     * @return self
     */
    public function setVisible($visible = true)
    {
        $this->visible = $visible;
        return $this;
    }


    /**
     * Returns the column visibility.
     *
     * @return bool
     */
    public function isVisible()
    {
        return $this->visible;
    }


    /**
     * Set a field searchable with the default filterPanel
     * a field is searchable by default
     *
     * @see widget_TableModelView::filterPanel()
     *
     * @param bool $visible
     * @return self
     */
    public function setSearchable($searchable = true)
    {
        $this->searchable = $searchable;
        return $this;
    }


    /**
     * Test if a field should be searchable
     *
     * @see widget_TableModelView::filterPanel()
     *
     * @return bool
     */
    public function isSearchable()
    {
        return $this->searchable;
    }




    /**
     * @param bool $sortable
     * @return self
     */
    public function setSortable($sortable = true)
    {
        $this->sortable = $sortable;
        return $this;
    }


    /**
     * @return bool
     */
    public function isSortable()
    {
        return $this->sortable;
    }

    /**
     * Enable or disable column visibility in HTML list
     * @param bool $inList
     * @return self
     */
    public function setInList($inList = true)
    {
        $this->inList = $inList;
        return $this;
    }

    /**
     * @return bool
     */
    public function isInList()
    {
        return $this->inList;
    }


    /**
     * @param bool $exportable
     * @return self
     */
    public function setExportable($exportable = true)
    {
        $this->exportable = $exportable;
        return $this;
    }


    /**
     * @return bool
     */
    public function isExportable()
    {
        return $this->exportable;
    }



    /**
     * @param bool   $selectable
     * @param string $selectableName
     * @return self
     */
    public function setSelectable($selectable = true, $selectableName = null)
    {
        $this->selectable = $selectable;
        $this->selectableName = $selectableName;
        return $this;
    }



    /**
     * @return string
     */
    public function getSelectableName()
    {
        if (isset($this->selectableName)) {
            return $this->selectableName;
        }
        return $this->getDescription();
    }


    /**
     * @return bool
     */
    public function isSelectable()
    {
        return $this->selectable;
    }


    /**
     * Add the specified class names to the column.
     *
     * @param string $className,... One or more class names.
     * @return self
     */
    public function addClass($className /*,... */)
    {
        $args = func_get_args();
        $numArgs = func_num_args();
        for ($i = 0; $i < $numArgs; $i++) {
            $this->classes[] = $args[$i];
        }
        return $this;
    }




    /**
     * Returns an array of css classes associated to the column.
     * @return string[]
     */
    public function getClasses()
    {
        return $this->classes;
    }
}




class widget_TableModelView extends Widget_TableView
{
    /**
     * @var ORM_Iterator    The data source.
     */
    protected $iterator = null;

    /**
     * @var int             The current page.
     */
    private $currentPage = null;

    /**
     * @var int             The maximum number of rows displayed on the page.
     */
    private $pageLength = null;

    /**
     *
     * @var int             The maximum number of rows displayed
     */
    private $limit = null;

    /**
     *
     * @var string
     */
    private $anchorname;

    /**
     *
     * @var bool
     */
    private $doGrouping = false;

    /**
     *
     * @var bool
     */
    protected $allowColumnSelection = null;

    /**
     *
     * @var bool
     */
    protected $displayNumberOfRows = false;


    /**
     * @var Widget_PageSelector
     */
    private $pageSelector;


    /**
     * @var array           Information about columns
     */
    protected $columns = array();
    protected $colCount = null;

    protected $visibleColumns = array();
    public $columnsDescriptions = array();

    public $sortBaseUrl = null;
    public $sortParameterName = null;

    public $sortAjaxAction = null;

    public $pageAjaxAction = null;

    public $pageLengthAjaxAction = null;

    protected $sortAscending = null;
    protected $sortField = null;


    /**
     * The default sort field and direction path (fieldname:{up|down})
     * @var string
     */
    protected $defaultSortField = null;


    /**
     * The counter is used to generate unique ids.
     * @var int $counter
     */
    private static $counter = 1;

    /**
     * Filter form submit button
     */
    protected $submit = null;

    /**
     * @param string $id      The item unique id.
     */
    public function __construct($id = null)
    {
        parent::__construct(null, $id);
    }


    /**
     * Generates and return a unique id for the current page.
     * use a counter only affected by other widget of same type
     */
    protected function createId()
    {
        return strtolower(get_class($this)) . self::$counter++;
    }


    /**
     * Defines if the user will be allowed to select visible columns.
     *
     * @param bool $allow
     * @return self
     */
    public function allowColumnSelection($allow = true)
    {
        $this->allowColumnSelection = $allow;
        return $this;
    }

    /**
     * @return bool
     */
    public function isColumnSelectionAllowed()
    {
        if (null === $this->allowColumnSelection) {
            // autodetect column selection status (default)
            foreach ($this->columns as $column) {
                /*@var $column widget_TableModelViewColumn */
                if (! $column->isVisible()) {
                    $this->allowColumnSelection = true;
                    return true;
                }
            }

            $this->allowColumnSelection = false;
            return false;
        }


        return $this->allowColumnSelection;
    }

    /**
     * @param   bool    $status
     * @return self
     */
    public function displayNumberOfRows($status = true)
    {
        $this->displayNumberOfRows = $status;
        return $this;
    }

    /**
     * @return bool
     */
    public function isNumberOfRowsDisplayed()
    {
        return $this->displayNumberOfRows;
    }



    /**
     * Sets the data source.
     *
     * @param ORM_Iterator $iterator
     * @return self
     */
    public function setDataSource(ORM_Iterator $iterator)
    {
        $this->iterator = $iterator;
        return $this;
    }


    /**
     * Get data source
     * @return ORM_Iterator
     */
    public function getDataSource()
    {
        return $this->iterator;
    }


    /**
     * @return string
     */
    private function getCsvHeader($separator)
    {
        if (!isset($this->iterator) || empty($this->columns)) {
            return '';
        }

        $set = $this->iterator->getSet();

        $this->initColumns($set);


        $line = array();
        foreach ($this->columns as $columnPath => $column) {
            /* @var $column widget_TableModelViewColumn */
            if (!$column->isExportable()) {
                continue;
            }
            if (!isset($this->columnsDescriptions[$columnPath])) {
                $this->columnsDescriptions[$columnPath] = (string) $column->getDescription();
            }
            $text = $this->columnsDescriptions[$columnPath];
            $line[] = '"' . str_replace(array('"', "\r\n"), array('""',"\n"), $text) . '"';
        }

        return implode($separator, $line) . "\r\n";
    }


    /**
     * @param ORM_Record $record
     * @param int $row
     * @param string $separator
     *
     * @return string
     */
    private function getCsvRow(ORM_Record $record, &$row, $separator)
    {
        $record = $this->initRow($record, $row);
        if ($this->handleRow($record, $row)) {
            $row++;
        }
        $line = array();
        foreach ($this->columns as $fieldPath => $column) {
            /* @var $column widget_TableModelViewColumn */
            if (!$column->isExportable()) {
                continue;
            }
            $text = $this->computeCellTextContent($record, $fieldPath);
            $line[] = '"' . str_replace(array('"', "\r\n"), array('""',"\n"), $text) . '"';
        }

        return implode($separator, $line) . "\r\n";
    }


    /**
     * @param string $separator
     *
     * @return string
     */
    public function exportCsv($separator = ',')
    {
        $set = $this->iterator->getSet();

        $this->initColumns($set);
        $csv = $this->getCsvHeader($separator);

        $row = 0;
        $this->iterator->seek(0);
        while ($this->iterator->valid()) {
            $record = $this->iterator->current();
            $csv .= $this->getCsvRow($record, $row, $separator);
            $this->iterator->next();
        }

        return $csv;
    }


    /**
     *
     * @param string $filename
     */
    public function downloadExcel($filename = null)
    {
        if (!isset($this->iterator) || empty($this->columns)) {
            die();
        }
        /* @var $ExcelExport Func_ExcelExport */
        $ExcelExport = bab_functionality::get('ExcelExport');

        if (!isset($ExcelExport)) {
            $message = widget_translate('The ExcelExport functionality must be available to export as an Excel spreadsheet.');
            throw new Exception($message);
        }

        if (!isset($filename)) {
            $name = $this->getName();
            if (!empty($name)) {
                $filename = 'export-' . $name . '.xls';
            } else {
                $filename = 'export.xls';
            }

        }
        $ExcelExport->setDownloadFilename($filename);

        $workbook = $ExcelExport->getWorkbook('0.9.2');

        bab_setTimeLimit(3600);


        $worksheet = $workbook->addWorksheet('Page 1');

        $set = $this->iterator->getSet();

        $this->initColumns($set);


        $col = 0;
        $row = 0;
        foreach ($this->columns as $columnPath => $column) {
            /* @var $column widget_TableModelViewColumn */
            if (!$column->isExportable()) {
                continue;
            }
            if (!isset($this->columnsDescriptions[$columnPath])) {
                $this->columnsDescriptions[$columnPath] = (string) $column->getDescription();
            }
            $text = $this->columnsDescriptions[$columnPath];
            $worksheet->setColumn($col, $col + 1, 15);
            $worksheet->write($row, $col, bab_convertStringFromDatabase($text, 'CP1252'));
            $col++;
        }


        $this->iterator->seek(0);
        while ($this->iterator->valid()) {
            $record = $this->iterator->current();

            $record = $this->initRow($record, $row);
            if ($this->handleRow($record, $row)) {
                $row++;
            }
            $col = 0;
            foreach ($this->columns as $fieldPath => $column) {
                /* @var $column widget_TableModelViewColumn */
                if (!$column->isExportable()) {
                    continue;
                }
                $text = $this->computeCellTextContent($record, $fieldPath);
                $worksheet->write($row, $col, bab_convertStringFromDatabase($text, 'CP1252'));
                $col++;
            }

            $this->iterator->next();
        }

        $workbook->close();
        die;
    }



    /**
     *
     * @param string $filename
     */
    public function downloadXlsx($filename = null)
    {
        if (!isset($this->iterator) || empty($this->columns)) {
            die();
        }
        /* @var $ExcelxExport Func_ExcelxExport */
        $ExcelxExport = bab_functionality::get('ExcelxExport');

        if (!isset($ExcelxExport)) {
            $message = widget_translate('The ExcelxExport functionality must be available to export as an Excel spreadsheet.');
            throw new Exception($message);
        }

        if (!isset($filename)) {
            $name = $this->getName();
            if (!empty($name)) {
                $filename = 'export-' . $name . '.xlsx';
            } else {
                $filename = 'export.xlsx';
            }

        }

        $set = $this->iterator->getSet();
        $this->initColumns($set);

        $nbRows = $this->iterator->count()+1;
        $nbCols = count($this->columns);
        $workbook = $ExcelxExport->getWorkbook();
        $workbook->setFilename($filename);

        bab_setTimeLimit(3600);


        $worksheet = $workbook->addSheet($nbRows, $nbCols, 'Page 1');

        $col = 0;
        $row = 0;

        $worksheet->initRow();

        $columnTypes = array();

        foreach ($this->columns as $columnPath => $column) {
            /* @var $column widget_TableModelViewColumn */
            if (!$column->isExportable()) {
                continue;
            }
            if (!isset($this->columnsDescriptions[$columnPath])) {
                $this->columnsDescriptions[$columnPath] = (string) $column->getDescription();
            }

            $field = $column->getField();
            if ($field instanceof ORM_DateField) {
                $type = 'date';
            } elseif ($field instanceof ORM_DatetimeField) {
                $type = 'datetime';
            } else {
                $type = 'string';
            }
            $columnTypes[$columnPath] = $type;
            $text = $this->columnsDescriptions[$columnPath];
            $worksheet->addCell(bab_convertStringFromDatabase(str_replace(chr(11), '', $text), bab_charset::UTF_8));
            $col++;
        }

        $worksheet->closeRow();


        $this->iterator->seek(0);
        while ($this->iterator->valid()) {
            $record = $this->iterator->current();

            $record = $this->initRow($record, $row);
            if ($this->handleRow($record, $row)) {
                $row++;
            }
            $col = 0;

            $worksheet->initRow();

            foreach ($this->columns as $columnPath => $column) {
                /* @var $column widget_TableModelViewColumn */
                if (!$column->isExportable()) {
                    continue;
                }

                if ($columnTypes[$columnPath] == 'string') {
                    $text = $this->computeCellTextContent($record, $columnPath);
                } else {
                    $text = self::getRecordFieldRawValue($record, $columnPath);
                }

                $worksheet->addCell(
                    bab_convertStringFromDatabase(str_replace(chr(11), '', $text), bab_charset::UTF_8),
                    $columnTypes[$columnPath]
                );
                $col++;
            }

            $worksheet->closeRow();

            $this->iterator->next();
        }

        $worksheet->closeSheet();

        $workbook->downloadFile();
        die;
    }



    /**
     * @param string    $filename
     * @param string    $separator
     * @param bool      $inline
     * @param string    $charset        Charset of output file
     *
     */
    public function downloadCsv($filename, $separator = ',', $inline = false, $charset = 'ISO-8859-15')
    {
        if (!isset($this->iterator) || empty($this->columns)) {
            throw new ErrorException('Failed to create the CSV file');
        }

        //DOWNLOAD
        bab_setTimeLimit(3600);

        if (mb_strtolower(bab_browserAgent()) == 'msie') {
            header('Cache-Control: public');
        }

        if ($inline) {
            header('Content-Disposition: inline; filename="'.$filename.'"'."\n");
        } else {
            header('Content-Disposition: attachment; filename="'.$filename.'"'."\n");
        }

        $mime = 'text/csv';
        header('Content-Type: '.$mime."\n");
        header('Content-transfert-encoding: binary'."\n");


        if ('UTF-8 BOM' === $charset) {
            $charset = 'UTF-8';
            echo "\xEF\xBB\xBF";
        }

        $set = $this->iterator->getSet();

        $this->initColumns($set);
        echo bab_convertStringFromDatabase($this->getCsvHeader($separator), $charset);

        $row = 0;
        $this->iterator->seek(0);
        while ($this->iterator->valid()) {
            $record = $this->iterator->current();
            echo bab_convertStringFromDatabase($this->getCsvRow($record, $row, $separator), $charset);
            $this->iterator->next();
        }

        die(); // end of file

    }



    /**
     * Returns a simple printable html version of the modeltableview.
     *
     * @return string
     */
    public function exportPrintableHtml()
    {
        if (!isset($this->iterator) || empty($this->columns)) {
            return '';
        }

        $set = $this->iterator->getSet();

        $this->initColumns($set);

        $html = '<table class="widget-printable-table">';


        $line = array();
        foreach ($this->columns as $columnPath => $column) {
            /* @var $column widget_TableModelViewColumn */
            if (!$column->isExportable()) {
                continue;
            }
            if (!isset($this->columnsDescriptions[$columnPath])) {
                $this->columnsDescriptions[$columnPath] = (string) $column;
            }
            $text = $this->columnsDescriptions[$columnPath];
            $line[] = bab_toHtml($text);
        }

        $html .= '<thead>';
        $html .= '<tr>';
        $html .= '<th>' . implode('</th><th>', $line) . '</th>';
        $html .= '</tr>';
        $html .= '</thead>';

        $row = 0;

        $html .= '<tbody>';
        $this->iterator->seek(0);
        while ($this->iterator->valid()) {
            $record = $this->iterator->current();
            $this->iterator->next();
            if ($record = $this->initRow($record, $row)) {
                $row++;
            }
            $line = array();
            foreach ($this->columns as $fieldPath => $column) {
                /* @var $column widget_TableModelViewColumn */
                if (!$column->isExportable()) {
                    continue;
                }
                $text = $this->computeCellTextContent($record, $fieldPath);
                $line[] = bab_toHtml($text);
            }

            $html .= '<tr>';
            $html .= '<td>' . implode('</td><td>', $line) . '</td>';
            $html .= '</tr>';
        }

        $html .= '</tbody>';
        $html .= '</table>';



        return $html;
    }


    /**
     * Sets the maximum number of rows that shall be displayed at once.
     *
     * @param int $pageLength       or null to unset the limit.
     * @return self
     */
    public function setPageLength($pageLength = null)
    {
        $this->pageLength = $pageLength;
        return $this;
    }

    /**
     * Returns the maximum number of rows that shall be displayed at once.
     *
     * @return int      The maximum number of rows displayed or null if no limit.
     */
    public function getPageLength()
    {
        return $this->pageLength;
    }



    /**
     * Sets the maximum number of rows
     *
     * @param int $limit        or null to unset the limit.
     * @return self
     */
    public function setLimit($limit = null)
    {
        $this->limit = $limit;
        return $this;
    }

    /**
     * Returns the maximum number of rows
     *
     * @return int      The maximum number of rows
     */
    public function getLimit()
    {
        return $this->limit;
    }



    /**
     * Sets the currently displayed page. Displayed data depends on pageLength.
     *
     * @param $pageNumber       First page is 0.
     * @return self
     */
    public function setCurrentPage($pageNumber)
    {
        $this->currentPage = $pageNumber;
        return $this;
    }


    /**
     * Returns the currently displayed page.
     *
     * @return int      The currently displayed page. First page is 0.
     */
    public function getCurrentPage()
    {
        return $this->currentPage;
    }


    /**
     * Defines the data source field that will be used to perform sorting.
     *
     * @param string $fieldPathAndOrder
     * @return $this
     */
    public function setSortField($fieldPathAndOrder)
    {
        list($fieldPath, $order) = explode(':', $fieldPathAndOrder . ':');
        $this->sortAscending = ($order !== 'down');
        $this->sortField = $fieldPath;

        return $this;
    }

    /**
     * Returns the data source field that will be used to perform sorting.
     *
     * @return string | null
     */
    public function getSortField()
    {
        if (!isset($this->sortField)) {
            return null;
        }
        return $this->sortField . ':' . ($this->sortAscending ? 'up' : 'down');
    }



    /**
     * Defines if grouping should be performed.
     *
     * @param bool  $doGrouping
     * @return self
     */
    public function setGrouping($doGrouping)
    {
        $this->doGrouping = $doGrouping;
        return $this;
    }


    /**
     * Return the grouping status of this tablemodelview.
     *
     * @return bool
     */
    public function isGrouping()
    {
        return $this->doGrouping;
    }


    /**
     * @param array     $columns
     * @return self
     *
     * @deprecated by setAvailableColumns
     * @see widget_TableModelView::setAvailableColumns
     */
    public function setVisibleColumns(array $columns, $recordSet = null)
    {
        if (!isset($recordSet)) {
            $recordSet = $this->iterator->getSet();
        }
        foreach ($columns as $path => $columnLabel) {
            if ($field = self::getRecordSetField($recordSet, $path)) {
                $col = widget_TableModelViewColumn($field, $columnLabel);
            } else {
                $col = widget_TableModelViewColumn($path, $columnLabel);
            }
            if (isset($col)) {
                $this->addColumn($col);
            }
        }

        return $this;
    }


    /**
     *
     * @return array
     */
    public function getVisibleColumns()
    {
        if (empty($this->columnsDescriptions)) {
            $this->initColumns($this->iterator->getSet());
        }
        return $this->columns;
    }






    /**
     * Sets the sort field path.
     *
     * @param string $defaultSortField  fieldpath:{up|down}
     *
     * @return self
     */
    public function setDefaultSortField($defaultSortField)
    {
        $this->defaultSortField = $defaultSortField;
        return $this;
    }

    /**
     * Returns the current sort field path.
     * If no default sort field has been set, sets the first column with a field associated as
     * the default sort field.
     *
     * @return string
     */
    public function getDefaultSortField()
    {
        if (!isset($this->defaultSortField)) {
            foreach ($this->columns as $path => $column) {
                if (null !== $column->getField()) {
                    $this->defaultSortField = $path;
                    break;
                }
            }
        }

        return $this->defaultSortField;
    }





    /**
     * Adds a column to the table model view.
     *
     * @param widget_TableModelViewColumn $column The column description.
     * @param int $position                       Unused for the time being.
     * @return self
     */
    public function addColumn(widget_TableModelViewColumn $column, $position = null)
    {
        $colPath = $column->getFieldPath();
        $this->columns[$colPath] = $column;

        $colIndex = $this->getColumnIndex($colPath);
        $classes = $column->getClasses();
        if (!empty($classes)) {
            $className = implode(' ', $classes);
            $this->addColumnClass($colIndex, $className);
        }
        return $this;
    }


    /**
     * @param array     $columns
     * @return self
     */
    public function setAvailableColumns(array $columns)
    {
        foreach ($columns as $column) {
            $this->addColumn($column);
        }

        return $this;
    }




    /**
     * Get a generic filter panel
     * Use setPageLength to define the default number of items per page
     *
     *
     * @param   string  $name       optional filter form name
     * @param   array   $filter     optional filter values, if not set, the filter will be used from request and the name parameter
     *
     *
     * @return Widget_Filter
     */
    public function filterPanel($name = 'search', $filter = null)
    {
        require_once dirname(__FILE__).'/filter.class.php';

        $filterPanel = new Widget_Filter;

        if (isset($name)) {
            $filterPanel->setName($name);
        }

        $search = bab_rp($name);
        if (null === $filter && $search && isset($search['filter'])) {
            $filter = $search['filter'];
        }

        $pageLength = $this->getPageLength();
        if (null === $pageLength) {
            $pageLength = 15;
        }

        $currentPage = $this->getCurrentPage();
        if (null === $currentPage) {
            $currentPage = 0;
        }


        $this->setPageLength(isset($filter['pageSize']) ? $filter['pageSize'] : $pageLength);
        $this->setCurrentPage(isset($filter['pageNumber']) ? $filter['pageNumber'] : $currentPage);

        $this->sortParameterName = $name . '[filter][sort]';

        if (isset($filter['sort'])) {
            $this->setSortField($filter['sort']);
        } elseif (!isset($this->sortField)) {
            $this->setSortField($this->getDefaultSortField());
        }

        $form = $this->getFilterForm();

        if (isset($filter)) {
            $form->setValues($filter, array($name, 'filter'));
        }

        $filterPanel->setFilter($form);
        $filterPanel->setFiltered($this);

        return $filterPanel;
    }




    /**
     * @param ORM_RecordSet $set
     * @param string        $fieldPath
     *
     * @return ORM_Field        or null
     */
    protected static function getRecordSetField(ORM_RecordSet $set, $fieldPath)
    {
        $fieldPathElements = explode('/', $fieldPath);
        $field = $set;
        foreach ($fieldPathElements as $fieldName) {
            if (!$field->fieldExist($fieldName)) {
                return null;
            }
            $field = $field->$fieldName;
        }
        return $field;
    }



    /**
     * @param ORM_Record    $record
     * @param string        $fieldPath
     *
     * @return mixed
     */
    protected static function getRecordFieldRawValue(ORM_Record $record, $fieldPath)
    {
        $fieldPathElements = explode('/', $fieldPath);
        $value = $record;
        $field = $record->getParentSet();
        foreach ($fieldPathElements as $fieldName) {
            if (!$field->fieldExist($fieldName)) {
                return null;
            }
            $field = $field->$fieldName;
            $value = $value->$fieldName;
        }

        return $value;
    }




    /**
     * @param ORM_Record    $record
     * @param string        $fieldPath
     *
     * @return mixed
     */
    protected static function getRecordFieldValue(ORM_Record $record, $fieldPath)
    {
        $fieldPathElements = explode('/', $fieldPath);
        $value = $record;
        $field = $record->getParentSet();

        if (!($field instanceof ORM_RecordSet)) {
            throw new Exception('Failed to get parent set from '.get_class($record));
        }

        foreach ($fieldPathElements as $fieldName) {

            if (!($field instanceof ORM_RecordSet)) {
                throw new Exception('Failed to get set from path '.$fieldPath.' field:'.$field->getName());
            }

            if (!$field->fieldExist($fieldName)) {
                return null;
            }
            $field = $field->$fieldName;
            $value = $value->$fieldName;


        }

        /*@var $field ORM_Field */

        return $field->output($value);
    }




    /**
     * @param ORM_Record    $record
     * @param string        $fieldPath
     *
     * @return mixed
     */
    protected static function getRecordFieldWidget(ORM_Record $record, $fieldPath)
    {
        $fieldPathElements = explode('/', $fieldPath);
        $value = $record;
        foreach ($fieldPathElements as $fieldName) {
            $value = $value->$fieldName;
        }
        return $value;
    }




    /**
     * Creates the key corresponding to an ORM_Field
     *
     * @param ORM_Field $field
     * @return string
     */
    public static function getFieldPath(ORM_Field $field)
    {
        $fieldPath = $field->getName();
        for ($parentSet = $field->getParentSet(); $parentSet !== null; $parentSet = $parentSet->getParentSet()) {
            if ($parentSet->getName() !== '') {
                $fieldPath = $parentSet->getName() . '/' . $fieldPath;
            }
        }
        return $fieldPath;
    }




    /**
     * Set default columns from fields
     * All columns from SET except primary keys and foreign keys
     *
     * @param   ORM_RecordSet   $set
     */
    private function setDefaultColumns(ORM_RecordSet $set)
    {
        $setFields = $set->getFields();

        foreach ($setFields as $setField) {
            if ($setField instanceof ORM_FkField || $setField instanceof ORM_PkField) {
                continue;
            }

            if ($setField instanceof ORM_RecordSet) {
                $this->setDefaultColumns($setField);
            } else {
                $col = widget_TableModelViewColumn($setField, $setField->getDescription());
                if (isset($col)) {
                    $this->addColumn($col);
                }
            }
        }
    }


    protected function initTotal()
    {

    }


    /**
     * Add the default collumns of a widget table modelview
     * inherithed classes should use this method to add the collumns with the addColumn method
     *
     * @see widget_TableModelView::addColumn
     *
     * @param   ORM_RecordSet   $set
     *
     * @return self
     */
    public function addDefaultColumns(ORM_RecordSet $set)
    {
        // default behaviour witch need to be overloaded : display all columns of set
        $this->setDefaultColumns($set);

        return $this;
    }



    /**
     * Column initialisation from recordSet
     * @param   ORM_RecordSet   $set
     *
     */
    protected function initColumns(ORM_RecordSet $recordSet)
    {
        /* @var $W Func_Widgets */
        $W = bab_Functionality::get('Widgets', false);

        if (0 === count($this->columns)) {
            // Missing column initialisation, default mode
            $this->setDefaultColumns($recordSet);
            return;
        }

        if ($this->isColumnSelectionAllowed()) {
            // If column selection is allowed, we fetch the visibility state
            // of the columns in the user configuration.
            foreach ($this->columns as $columnPath => $column) {
                $visible = $W->getUserConfiguration($this->getId() . '/columns/' . $columnPath);
                if (isset($visible)) {
                    $column->setVisible($visible);
                }
            }
        }

        $i = 0;
        foreach ($this->columns as $path => $column) {

            if (!$column->isInList()) {
                continue;
            }

            /* @var $column widget_TableModelViewColumn */
            if (!$column->isVisible()) {
                $this->addColumnClass($i, 'widget-hidden-column');
            }
            $i++;

            $this->columnsDescriptions[$path] = $column->getDescription();
        }

    }


    protected function countColumns()
    {
        if (null === $this->colCount) {
            $this->colCount = 0;
            foreach ($this->columns as $column) {

                if (!$column->isInList()) {
                    continue;
                }

                $this->colCount++;
            }
        }


        return $this->colCount;
    }



    protected function addHeaderSection()
    {
        $this->addSection('header', null, 'widget-table-header');
        return $this;
    }



    /**
     * Called before data rows
     * @return void
     */
    protected function initHeaderRow(ORM_RecordSet $set)
    {
        require_once $GLOBALS['babInstallPath'] . 'utilit/urlincl.php';

        bab_Functionality::includefile('Icons');

        $W = bab_Widgets();


        $this->addHeaderSection();
        $this->setCurrentSection('header');

        $col = 0;

        foreach ($this->columns as $columnPath => $column) {

            if (!$column->isInList()) {
                continue;
            }

            if (!isset($this->columnsDescriptions[$columnPath])) {
                $this->columnsDescriptions[$columnPath] = $column->getDescription();
            }

            $columnLabel = $this->columnsDescriptions[$columnPath];
            if (isset($this->sortParameterName) && self::getRecordSetField($set, $columnPath) && $column->isSortable()) {
                if (!isset($this->sortBaseUrl)) {
                    $this->sortBaseUrl = bab_url::request_gp();
                }

                if ($this->sortField === $columnPath && $this->sortAscending) {
                    $direction = ':down';
                } else {
                    $direction = ':up';
                }

                $url = bab_url::mod($this->sortBaseUrl, $this->sortParameterName, $columnPath . $direction);
                if ($anchor = $this->getAnchor()) {
                    $url .= '#'.urlencode($anchor);
                }

                $columnItem = $W->Link($columnLabel, $url);
                if ($this->sortAjaxAction) {
                    $columnItem->setAjaxAction(
                        $this->sortAjaxAction->setParameter('sort', $columnPath . $direction),
                        $this
                    );
                }
            } else {
                $columnItem = $W->Label($columnLabel);
            }

            $this->addItem($columnItem, 0, $col++);
        }

        if ($this->isColumnSelectionAllowed()) {
            $columnSelectionMenu = $this->columnSelectionMenu($this->columns);
            $this->addItem($columnSelectionMenu, 0, $col);
            $this->addColumnClass($col, 'widget-column-minimal-width');
        }
    }



    /**
     * Returns a menu with the list of column names.
     * Clicking a column name in the menu toggles its visibility in the tablemodelview.
     *
     * @return Widget_Menu
     */
    protected function columnSelectionMenu($columns)
    {
        $W = bab_Widgets();

        $columnSelectionMenu = $W->Menu(null, $W->HBoxLayout()->setHorizontalSpacing(2, 'em'));
        $columnSelectionMenu->setTitle(widget_translate('Table configuration'));

        $columnSelectionMenu->addClass(Func_Icons::ICON_LEFT_16, 'widget-tableview-column-menu', 'widget-popup-dialog');

        $columnsBox = $W->VBoxItems();
        $columnsBox->addClass('widget-100pc');
        $columnsBox->setSizePolicy('widget-30em');
        $columnSelectionMenu->addItem($columnsBox);

        $columnsBox->addItem(
            $W->LabelledWidget(
                widget_translate('Choose displayed columns'),
                $columnList = $W->VBoxItems()
            )
        );
        $col = 0;
        $currentPageAction = Widget_Action::fromRequest();

        foreach ($columns as $path => $column) {

            if (!$column->isInList()) {
                continue;
            }
            if ($column->isSelectable() && $column->getDescription() != '') {
                $columnList->addItem(
                    $W->Link(
                        $column->getSelectableName(),
                        $currentPageAction

                    )->addClass('icon', 'column-toggle', $column->isVisible() ? Func_Icons::ACTIONS_DIALOG_OK . ' widget-strong' : '')
                    ->setSizePolicy('widget-list-element')
                    ->setMetaData('cellIndex', $col)
                    ->setMetaData('columnName', $path)
                );
            }
            $col++;
        }

        $linesBox = $W->VBoxItems();
        $linesBox->setVerticalSpacing(3, 'em');
        $linesBox->addClass('widget-100pc');
        $linesBox->setSizePolicy('widget-20em');
        $columnSelectionMenu->addItem($linesBox);


        if (isset($this->pageLengthAjaxAction)) {

            $linesBox->addItem(
                $W->LabelledWidget(
                    widget_translate('Number of lines per page'),
                    $pageLengthSelect = $W->Select()
                        ->addAttribute('name', 'pageLength')
                        ->addOption('5', '5')
                        ->addOption('10', '10')
                        ->addOption('15', '15')
                        ->addOption('20', '20')
                        ->addOption('30', '30')
                        ->addOption('50', '50')
                        ->addOption('100', '100')
                )
            );
            $pageLengthSelect->setValue($this->getPageLength());
            $action = clone $this->pageLengthAjaxAction;
            $action->setParameter('pageLength', null);
            $pageLengthSelect->setAjaxAction($action, $this, 'change');
        }

        $linesBox->addItem(
            $W->Link(
                widget_translate('Reset to default columns'),
                $currentPageAction
            )->addClass('icon', 'widget-actionbutton', 'columns-reset', Func_Icons::ACTIONS_VIEW_REFRESH)
        );

        return $columnSelectionMenu;
    }



    /**
     * Called after data rows
     *
     * @param   int $row        Last row number +1
     */
    protected function initFooterRow($row)
    {
        $this->addSection('footer', null, 'widget-table-footer');
        $this->setCurrentSection('footer');

        // may be used in inherited classes
    }




    /**
     *
     * @param ORM_Record    $record
     * @param string        $fieldPath
     * @return string       The text of the item that will be placed in the cell
     */
    protected function computeCellTextContent(ORM_Record $record, $fieldPath)
    {
        $cellTextContent = self::getRecordFieldValue($record, $fieldPath);
        return $cellTextContent;
    }



    /**
     *
     * @param ORM_Record    $record
     * @param string        $fieldPath
     * @return Widget_Item  The item that will be placed in the cell
     */
    protected function computeCellContent(ORM_Record $record, $fieldPath)
    {
        $W = bab_Widgets();

        $cellContent = $W->Html(bab_toHtml($this->computeCellTextContent($record, $fieldPath)));
        return $cellContent;
    }


    /**
     * Handle cell content, add the cell widget the the tableview
     *
     * @param   ORM_Record  $record         row record
     * @param   string      $fieldPath      collumn name as path is recordSet
     * @param   int         $row            row number in table
     * @param   int         $col            col number in table
     * @param   string      $name           if name is set, the cell widget will be added with a namedContainer
     *
     * @return  bool        True if a cell was added
     */
    protected function handleCell(ORM_Record $record, $fieldPath, $row, $col, $name = null, $rowSpan = null, $colSpan = null)
    {
        $cellContent = $this->computeCellContent($record, $fieldPath);

        if (isset($name)) {
            require_once dirname(__FILE__) . '/namedcontainer.class.php';
            $named = new Widget_NamedContainer($name);
            $named->addItem($cellContent);
            $this->addItem($named, $row, $col);
            return true;
        }

        $this->addItem($cellContent, $row, $col, $rowSpan, $colSpan);
        return true;
    }



    /**
     * Called just before initRow().
     * Should be used insert rows before the record row
     *
     * @param ORM_Record    $record
     * @param int           $row
     * @return int
     */
    protected function initRowNumber(ORM_Record $record, $row)
    {
        return $row;
    }


    /**
     * Called just before handleRow().
     * Should be used to perform initialization based on the ORM_Record.
     *
     * @param ORM_Record    $record
     * @param int           $row
     * @return ORM_Record
     */
    protected function initRow(ORM_Record $record, $row)
    {
        return $record;
    }


    /**
     * @param ORM_Record    $record
     * @param int           $row
     * @return bool         True if a row was added
     */
    protected function handleRow(ORM_Record $record, $row)
    {
        $col = 0;
        $nbColumns = $this->countColumns();
        foreach ($this->columns as $fieldPath => $column) {

            if (!$column->isInList()) {
                continue;
            }

            if ($this->isColumnSelectionAllowed() && $col === $nbColumns - 1) {
                $colSpan = 2;
            } else {
                $colSpan = null;
            }
            if ($this->handleCell($record, $fieldPath, $row, $col, null, null, $colSpan)) {
                $col++;
            }
        }
        return true;
    }


    /**
     * Get a form filter
     * @see Widget_Filter
     *
     * @param   string          $id
     * @param   Widget_Layout   $layout
     *
     * @return Widget_Form
     */
    public function getFilterForm($id = null, $layout = null)
    {
        require_once dirname(__FILE__).'/form.class.php';
        require_once dirname(__FILE__).'/flowlayout.class.php';
        require_once dirname(__FILE__).'/submitbutton.class.php';

        if (null === $layout) {
            $layout = new Widget_FlowLayout();
            $layout->setVerticalSpacing(1, 'em')->setHorizontalSpacing(1, 'em');
            $layout->setVerticalAlign('bottom');
        }


        $form = new Widget_Form($id);
        $form->setReadOnly(true);
        $form->setName('filter');
        $form->setLayout($layout);
        $form->colon();

        $this->handleFilterFields($form);
        if (! $this->submit) {
            $this->submit = new Widget_SubmitButton();
            $this->submit->setLabel(widget_translate('Filter'));
        }

        $form->addItem($this->submit);
        $form->setSelfPageHiddenFields();
        $form->setAnchor($this->getAnchor());

        return $form;
    }




    /**
     * Set filter form ajax action.
     *
     * @param Widget_Action             $action      A controller method accepting 3 optional parameters.
     * @param Widget_Item|string|array  $reloadItem  A Widget_Item, id of a Widget_Item, or array of Widget_Items
     * @param string                    $event       Not used for widget_TableModelView
     * @return self
     */
    public function setAjaxAction(Widget_Action $action = null, $reloadItem = null, $event = 'click')
    {
        if (! isset($action)) {
            $W = bab_Widgets();

            $inSession = false;

            $action = $W->Action();
            $action->setMethod(
                'addon/widgets/configurationstorage',
                'table',
                array(
                    'key' => $this->getId(),
                    'insession' => $inSession
                )
            );
            $this->setAjaxAction($action, $this);

            $pageLength = $W->getUserConfiguration($this->getId() . '/pageLength', 'widgets', $inSession);
            if (! isset($pageLength)) {
                $pageLength = 10;
            }
            $this->setPageLength($pageLength);

            $currentPage = $W->getUserConfiguration($this->getId() . '/page', 'widgets', $inSession);
            if (! isset($currentPage)) {
                $currentPage = 0;
            }
            $this->setCurrentPage($currentPage);

            $sortField = $W->getUserConfiguration($this->getId() . '/sort', 'widgets', $inSession);
            if (! isset($sortField)) {
                $sortField = $this->getDefaultSortField();
            }
            $this->setSortField($sortField);
        }

        $this->sortAjaxAction = $action;
        $this->pageAjaxAction = $action;
        $this->pageLengthAjaxAction = $action;

        $this->sortParameterName = 'sort';

        if (! $this->submit) {
            $this->submit = new Widget_SubmitButton();
            $this->submit->setLabel(widget_translate('Filter'));
        }
        $this->submit->setAjaxAction($action, $reloadItem);

        return $this;
    }




    /**
     * Returns the filters associated to the tablemodelview as an indexed array.
     *
     * @return array
     */
    public function getFilterValues()
    {
        $inSession = false;
        $W = bab_Widgets();
        $filter = $W->getUserConfiguration($this->getId() . '/filter', 'widgets', $inSession);
        if (!isset($filter)) {
            $filter = array();
        }
        return $filter;
    }





    /**
     * Sets the filters associated to the tablemodelview as an indexed array.
     *
     * @param array $filterValues
     */
    public function setFilterValues($filterValues)
    {
        $inSession = false;
        $W = bab_Widgets();
        $W->setUserConfiguration($this->getId() . '/filter', $filterValues, 'widgets', $inSession);
    }




    /**
     * Add the filter fields to the filter form
     * @param Widget_Form $form
     *
     */
    protected function handleFilterFields(Widget_Item $form)
    {
        $fields = $this->getVisibleColumns();

        foreach ($fields as $fieldName => $column) {
            /* @var $column widget_TableModelViewColumn */
            $field = $column->getField();
            if (! $column->isSearchable()) {
                continue;
            }

            if (! ($field instanceof ORM_Field)) {
                $field = null;
            }

            $label = $this->handleFilterLabelWidget($fieldName, $field);
            $input = $this->handleFilterInputWidget($fieldName, $field);

            if (isset($input) && isset($label)) {

                $input->setName($fieldName);
                $label->setAssociatedWidget($input);

                $form->addItem($this->handleFilterLabel($label, $input));
            }
        }
    }

    /**
     * Handle label for input field
     *
     * @param string    $fieldName
     * @param ORM_Field $field
     *
     * @return Widget_Label
     */
    protected function handleFilterLabelWidget($fieldName, ORM_Field $field = null)
    {
        require_once dirname(__FILE__).'/label.class.php';
        if (isset($this->columnsDescriptions[$fieldName])) {
            $description = $this->columnsDescriptions[$fieldName];
        }

        if (empty($description) && null !== $field) {
            $description = $field->getDescription();
        }

        if (empty($description) && null !== $field) {
            $description = $field->getName();
        }

        if (empty($description)) {
            $description = $fieldName;
        }

        return new Widget_Label($description);
    }


    /**
     * Handle label and input widget merge in one item before adding to the filter form
     * default is a vertical box layout
     *
     * @param Widget_Label                  $label
     * @param Widget_Displayable_Interface  $input
     * @return Widget_Item
     */
    protected function handleFilterLabel(Widget_Label $label, Widget_Displayable_Interface $input)
    {
        require_once dirname(__FILE__).'/vboxlayout.class.php';

        $layout = new Widget_VBoxLayout();

        $layout->addItem($label)
            ->addItem($input);

        return $layout;
    }




    /**
     * Returns the criteria corresponding to the specified value
     * for the specified field.
     *
     * @param ORM_Field $field
     * @param mixed $value
     *
     * @return ORM_Criteria
     */
    protected function getFieldFilterCriteria(ORM_Field $field, $value)
    {
        $criteria = null;

        switch (true) {
            case $field instanceof ORM_DateTimeField:
                $criteria = new ORM_TrueCriterion();
                if ('' !== $value['from']) {
                    $criteria = $criteria->_AND_($field->greaterThanOrEqual($field->input($value['from'])));
                }

                if ('' !== $value['to']) {
                    // add one day
                    require_once $GLOBALS['babInstallPath'].'utilit/dateTime.php';
                    $to = BAB_DateTime::fromIsoDateTime($field->input($value['to']));
                    $to->add(1, BAB_DATETIME_DAY);

                    $criteria = $criteria->_AND_($field->lessThanOrEqual($to->getIsoDateTime()));
                }
                break;

            case $field instanceof ORM_DateField:
                $criteria = new ORM_TrueCriterion();
                if ('' !== $value['from']) {
                    $criteria = $criteria->_AND_($field->greaterThanOrEqual($field->input($value['from'])));
                }

                if ('' !== $value['to']) {
                    // add one day
                    require_once $GLOBALS['babInstallPath'].'utilit/dateTime.php';
                    $to = BAB_DateTime::fromIsoDateTime($field->input($value['to']));
                    $to->add(1, BAB_DATETIME_DAY);

                    $criteria = $criteria->_AND_($field->lessThan($to->getIsoDate()));
                }
                break;

            case $field instanceof ORM_UserField:
                if ($value == 0) {
                    break;
                }
                //NO BREAK
            case $field instanceof ORM_RecordSet:
            case $field instanceof ORM_FkField:
            case $field instanceof ORM_PkField:
            case $field instanceof ORM_EnumField:
            case $field instanceof ORM_IntField:
            case $field instanceof ORM_BoolField:
                if (is_array($value)) {
                    $criteria = $field->in($value);
                } else {
                    $criteria = $field->is($field->input($value));
                }
                break;

            default:
                $criteria = $field->matchAll($field->input($value));

        }
        return $criteria;
    }



    /**
     * Build a default criteria from the filter.
     * This method needs orm field objects defined on columns.
     *
     * @param array $filter
     *                 Filter received from request, if filter not set try to
     *                 get it from the search param (default name used in
     *                 filterPanel() method)
     *
     * @return ORM_Criteria
     */
    public function getFilterCriteria($filter = null)
    {
        $Orm = bab_functionality::get('LibOrm');
        /*@var $Orm Func_LibOrm */
        $Orm->init();

        $criteria = new ORM_TrueCriterion;
        if (null === $filter) {
            $search = bab_rp('search');

            if (!isset($search['filter'])) {
                return $criteria;
            }

            $filter = $search['filter'];
        }

        if (empty($this->columns)) {
            trigger_error('The getFilterCriteria method should be called after the the addColumn method');
        }

        foreach ($this->columns as $fieldName => $column) {
            /* @var $column widget_TableModelViewColumn */
            $field = $column->getField();
            if (!($field instanceof ORM_Field)) {
                continue;
            }

            if (!isset($filter[$fieldName])) {
                continue;
            }

            $value = $filter[$fieldName];

            if ('' === $value) {
                continue;
            }

            $crit = $this->getFieldFilterCriteria($field, $value);
            if (isset($crit)) {
                $criteria = $criteria->_AND_($crit);
            }
        }

        return $criteria;
    }



    /**
     * Handle filter field input widget
     * If the method returns null, no filter field is displayed for the field
     *
     * @param   string          $name       table field name
     * @param   ORM_Field       $field      ORM field
     *
     * @return Widget_InputWidget | null
     */
    protected function handleFilterInputWidget($name, ORM_Field $field = null)
    {
        if (null === $field) {
            return null;
        }

        $W = bab_functionality::get('Widgets');

        if ($field instanceof ORM_DateField || $field instanceof ORM_DateTimeField) {
            return $W->PeriodPicker();

        } elseif ($field instanceof ORM_TimeField) {
            return $W->TimePicker();

        } elseif ($field instanceof ORM_StringField) {
            return $W->LineEdit()->setSize(min(array(20, $field->getMaxLength())));

        } elseif ($field instanceof ORM_ConcatOperation || $field instanceof ORM_ExtractValueOperation) {
            return $W->LineEdit();

        } elseif ($field instanceof ORM_EnumField) {
            $widget = $W->Select();
            $widget->addOption('', '');
            foreach ($field->getValues() as $key => $text) {
                $widget->addOption($key, $text);
            }

            return $widget;

        } elseif ($field instanceof ORM_FkField) {
            $widget = $W->Select();
            $widget->addOption('', '');
            $set = $field->newSet();

            if ($set === null) {
                return null;
            }

            $values = $set->select();
            foreach ($values as $record) {
                $widget->addOption($record->id, (string)$record->name);
            }

            return $widget;

        } elseif ($field instanceof ORM_RecordSet) {
            $widget = $W->Select();
            $widget->addOption('', '');
            $values = $field->select();

            foreach ($values as $record) {
                /*@var $record ORM_Record */
                $widget->addOption($record->id, $record->getRecordTitle());
            }

            return $widget;

        } elseif ($field instanceof ORM_UserField) {
            return $W->UserPicker()->addClass('widget-13em');

        } elseif ($field instanceof ORM_IntField) {
            return $W->LineEdit()->setSize(9);

        } elseif ($field instanceof ORM_TextField) {
            return $W->LineEdit()->setSize(20);

        } elseif ($field instanceof ORM_BoolField) {
            return $W->Select()
                ->addOption('', '')
                ->addOption(0, widget_translate('No'))
                ->addOption(1, widget_translate('Yes'));
        }

        return null;
    }



    /**
     * Returns the column numeric index for the specified column path.
     *
     * @param string $colPath
     *
     * @return int | null
     */
    public function getColumnIndex($colPath)
    {
        $colIndex = 0;
        $paths = array_keys($this->columns);
        foreach ($paths as $path) {
            if ($colPath === $path) {
                return $colIndex;
            }
            $colIndex++;
        }

        return null;
    }


    /**
     *
     * @param ORM_RecordSet $set
     * @param ORM_Iterator $iterator
     */
    protected function initSortField($set, $iterator)
    {
        if (!isset($this->sortField)) {
            return;
        }

        $colIndex = $this->getColumnIndex($this->sortField);


        if (isset($colIndex) && $sortField = self::getRecordSetField($set, $this->sortField)) {
            if ($this->sortAscending) {
                $this->addColumnClass($colIndex, 'widget-table-column-sorted-asc');
                $iterator->orderAsc($sortField);
            } else {
                $this->addColumnClass($colIndex, 'widget-table-column-sorted-desc');
                $iterator->orderDesc($sortField);
            }
        }
    }


    /**
     * Fills the table view with data from the data source.
     */
    protected function init()
    {
        $iterator = $this->iterator;

        if (!isset($iterator)) {
            return;
        }

        $set = $iterator->getSet();

        $this->initSortField($set, $iterator);
        $this->initColumns($set);
        $this->initHeaderRow($set);

        $this->addSection('body', null, 'widget-table-body');
        $this->setCurrentSection('body');

        $nbRows = $iterator->count();

        if (isset($this->pageLength)) {
            if ($this->currentPage > floor($nbRows / $this->pageLength)) {
                $this->currentPage = 0;
            }
        }

        $startRow = isset($this->pageLength) ? $this->currentPage * $this->pageLength : 0;
        $iterator->seek($startRow);

        $row = 0;

        $currentGroupValue = null;

        while ($iterator->valid() && (!isset($this->pageLength) || $row < $this->pageLength)) {

            if (isset($this->limit) && $row >= $this->limit) {
                break;
            }

            $record = $iterator->current();
            if ($this->isGrouping() && isset($this->sortField)) {
                $newGroupValue = self::getRecordFieldValue($record, $this->sortField);
                if ($newGroupValue !== $currentGroupValue) {
                    $this->addSection($newGroupValue, $newGroupValue);
                    $this->setCurrentSection($newGroupValue);
                    $currentGroupValue = $newGroupValue;
                }
            }
            $iterator->next();

            $row = $this->initRowNumber($record, $row);
            $record = $this->initRow($record, $row);
            if ($this->handleRow($record, $row)) {
                $row++;
            }
        }

        $this->initFooterRow($row);
    }



    /**
     * Set an anchor for destination page
     * @param string $anchorname
     * @return self
     */
    public function setAnchor($anchorname)
    {
        $this->anchorname = $anchorname;
        return $this;
    }


    /**
     * Get the anchor name of destination page
     * @return string | null
     */
    public function getAnchor()
    {
        return $this->anchorname;
    }

    /**
     * Get display of total number of rows
     *
     *
     * @return Widget_Item | null
     */
    protected function handleTotalDisplay()
    {
        if (!$this->isNumberOfRowsDisplayed()) {
            return null;
        }

        require_once dirname(__FILE__).'/frame.class.php';


        $frame = new Widget_Frame;
        $frame->addClass('totaldisplay');

        $n = $this->iterator->count();

        if ($n < 2) {
            return null;
        }

        $frame->addItem($this->handleTotalDisplayLabel($n));

        return $frame;
    }


    /**
     * Get display of total number of rows
     * @return Widget_Label
     */
    protected function handleTotalDisplayLabel($number)
    {
        require_once dirname(__FILE__).'/label.class.php';

        return new Widget_Label(sprintf(widget_translate('%d lines'), $number));
    }


    /**
     * @return Widget_PageSelector
     */
    protected function getPageSelector()
    {
        if (!isset($this->pageSelector)) {

            require_once dirname(__FILE__).'/pageselector.class.php';

            $selector = new Widget_PageSelector();
            $selector->setPageLength($this->getPageLength());
            $selector->setIterator($this->iterator);
            $selector->setCurrentPage($this->getCurrentPage());
            if (isset($this->pageAjaxAction)) {
                $action = clone $this->pageAjaxAction;
                $action->setParameter('sort', null);
                $selector->setAjaxAction($action, $this);
            }
            if (isset($this->sortField)) {
                $selector->setSortField($this->sortField);
            }

            $namePath = $this->getNamepath();
            $namePath[] = 'filter';
            $namePath[] = 'pageNumber';

            $selector->setPageNamePath($namePath);
            $selector->setAnchor($this->getAnchor());

            $this->pageSelector = $selector;
        }

        return $this->pageSelector;
    }



    /**
     * Get multi-page selector widget
     *
     *
     * @return Widget_Selector | null
     */
    protected function handlePageSelector()
    {
        $selector = $this->getPageSelector();

        if ($selector->getNbPages() > 1) {
            return $selector;
        }

        return null;
    }



    /**
     * Returns an array of css classes associated to the column.
     * @return string[]
     */
    public function getClasses()
    {
        $classes = parent::getClasses();
        $classes[] = 'widget-tablemodelview';

        if ($this->isNumberOfRowsDisplayed()) {
            $classes[] = 'widget-table-total-display';
        }

        $selector = $this->getPageSelector();
        if ($selector->getNbPages() > 1) {
            $classes[] = 'widget-filter-bottom';
        }

        return $classes;
    }


    /**
     * @see programs/widgets/Widget_TableView#display($canvas)
     * @todo make a variable of ['filter']['pageNumber']
     */
    public function display(Widget_Canvas $canvas)
    {
        $this->init();

        $items = array();

        $total = $this->handleTotalDisplay();
        $selector = $this->handlePageSelector();


        if (null !== $total) {
            $items[] = $total->display($canvas);
        }

        $list = parent::getLayout();
        $items[] = $list;

        if (null !== $selector) {
            $items[] = $selector->display($canvas);
        }

        $widgetsAddon = bab_getAddonInfosInstance('widgets');

        return $canvas->vbox(
            $this->getId(),
            $this->getClasses(),
            $items,
            $this->getCanvasOptions(),
            $this->getTitle(),
            $this->getAttributes()
        )
        . $canvas->metadata($this->getId(), $this->getMetadata())
        . $canvas->loadScript($this->getId(), $widgetsAddon->getTemplatePath() . 'widgets.tableview.jquery.js');
    }
}
