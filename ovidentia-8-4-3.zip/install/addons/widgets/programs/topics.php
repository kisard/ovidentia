<?php
//-------------------------------------------------------------------------
// OVIDENTIA http://www.ovidentia.org
// Ovidentia is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2, or (at your option)
// any later version.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
// USA.
//-------------------------------------------------------------------------
/**
 * @license http://opensource.org/licenses/gpl-license.php GNU General Public License (GPL)
 * @copyright Copyright (c) 2011 by CANTICO ({@link http://www.cantico.fr})
 */


function widgets_topicPickerSubTree($catId)
{
    $str = '';
    $cats = bab_getChildrenArticleCategoriesInformation($catId);
    foreach ($cats as $cat) {
        $str .= '<li>';
        $str .= '<a href="#">' . $cat['title'] . '</a>';
        $ul = widgets_topicPickerSubTree($cat['id']);
        if ($ul) {
            $str .= '<ul>' . $ul . '</ul>';
        }
        $str .= '</li>';
    }
    $tops = bab_getChildrenArticleTopicsInformation($catId);
    foreach ($tops as $top) {
        $str .= '<li><a href="#" title="' . $top['id'] . '">' . $top['title'] .
             '</a></li>';
    }
    
    return $str;
}

function widgets_topicPickerTree()
{
    require_once $GLOBALS['babInstallPath'] . 'utilit/artapi.php';
    
    $str = '<ul>';
    $str .= '<li><a href="#">Racine</a>';
    
    $str .= '<ul>';
    
    $cats = bab_getChildrenArticleCategoriesInformation(0);
    foreach ($cats as $cat) {
        $str .= '<li>';
        $str .= '<a href="#">' . $cat['title'] . '</a>';
        $ul = widgets_topicPickerSubTree($cat['id']);
        if ($ul) {
            $str .= '<ul>' . $ul . '</ul>';
        }
        $str .= '</li>';
    }
    
    $str .= '</ul>';
    $str .= '</li>';
    $str .= '</ul>';
    
    return $str;
}

switch (bab_rp('idx')) {
    case 'topicpicker':
        echo widgets_topicPickerTree();
        die();
}
