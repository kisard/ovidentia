;<?php /*

[general]
name							="widgets"
version							="1.0.81"
addon_type						="LIBRARY"
encoding						="UTF-8"
mysql_character_set_database	="latin1"
description						="User Interface Widgets"
description.fr					="Widgets, bibliothèque d'éléments de l'interface utilisateur"
delete							=1
ov_version						="8.1.0"
php_version						="5.1.0"
addon_access_control			="0"
author							="Laurent Choulette (laurent.choulette@cantico.fr)"
icon							="edit-rename.png"
mysql_character_set_database	="latin1,utf8"


;*/
